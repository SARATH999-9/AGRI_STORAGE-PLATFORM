// Updated JavaScript with API calls
document.addEventListener('DOMContentLoaded', function() {
    // API Base URL
    const API_BASE_URL = 'http://localhost:5000/api';

    // Splash Screen Animation
    setTimeout(() => {
        document.getElementById('splashScreen').style.display = 'none';
        document.getElementById('appContainer').classList.remove('hidden');
        
        // Start typing animation
        typeWriter();
    }, 3000);

    // Typing Animation for Welcome Text
    const welcomeTexts = [
        "ನಮಸ್ಕಾರ ರೈತರೇ",
        "స్వాగతం రైతులారా",
        "வணக்கம் விவசாயிகளே",
        "Welcome Farmers",
        "किसानों का स्वागत है"
    ];
    
    let textIndex = 0;
    let charIndex = 0;
    let isDeleting = false;
    
    function typeWriter() {
        const currentText = welcomeTexts[textIndex];
        const welcomeElement = document.getElementById('dynamicWelcome');
        
        if (isDeleting) {
            welcomeElement.textContent = currentText.substring(0, charIndex - 1);
            charIndex--;
        } else {
            welcomeElement.textContent = currentText.substring(0, charIndex + 1);
            charIndex++;
        }
        
        if (!isDeleting && charIndex === currentText.length) {
            isDeleting = true;
            setTimeout(typeWriter, 2000);
        } else if (isDeleting && charIndex === 0) {
            isDeleting = false;
            textIndex = (textIndex + 1) % welcomeTexts.length;
            setTimeout(typeWriter, 500);
        } else {
            setTimeout(typeWriter, isDeleting ? 50 : 100);
        }
    }

    // Enter App Button
    document.getElementById('enterAppBtn').addEventListener('click', function() {
        document.getElementById('welcomePage').style.display = 'none';
        document.getElementById('authSection').classList.remove('hidden');
    });

    // Toggle between Login and Register
    document.getElementById('showRegister').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('loginForm').classList.remove('active');
        document.getElementById('registerForm').classList.add('active');
    });

    document.getElementById('showLogin').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('registerForm').classList.remove('active');
        document.getElementById('loginForm').classList.add('active');
    });

    // Send Login OTP via Backend
    document.getElementById('sendLoginOTP').addEventListener('click', async function() {
        const email = document.getElementById('loginEmail').value;
        if (!email) {
            alert('Please enter your email first');
            return;
        }

        // Disable button to prevent multiple clicks
        this.disabled = true;
        this.textContent = 'Sending...';

        try {
            const response = await fetch(`${API_BASE_URL}/send-otp`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    purpose: 'Login to Farmer Portal'
                })
            });

            const data = await response.json();

            if (response.ok) {
                alert('OTP sent to your email successfully! Check your inbox.');
                // Enable OTP input
                document.getElementById('loginOTP').disabled = false;
            } else {
                alert(data.error || 'Failed to send OTP. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error. Please check your connection.');
        } finally {
            // Re-enable button
            this.disabled = false;
            this.textContent = 'Send OTP';
        }
    });

    // Send Register OTP via Backend
    document.getElementById('sendRegisterOTP').addEventListener('click', async function() {
        const email = document.getElementById('registerEmail').value;
        if (!email) {
            alert('Please enter your email first');
            return;
        }

        this.disabled = true;
        this.textContent = 'Sending...';

        try {
            const response = await fetch(`${API_BASE_URL}/send-otp`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    purpose: 'Registration for Farmer Portal'
                })
            });

            const data = await response.json();

            if (response.ok) {
                alert('OTP sent to your email successfully! Check your inbox.');
                document.getElementById('registerOTP').disabled = false;
            } else {
                alert(data.error || 'Failed to send OTP. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error. Please check your connection.');
        } finally {
            this.disabled = false;
            this.textContent = 'Send OTP';
        }
    });

    // Handle Login Form Submission
    document.getElementById('loginFormElement').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const enteredOTP = document.getElementById('loginOTP').value;

        try {
            const response = await fetch(`${API_BASE_URL}/verify-otp`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    otp: enteredOTP
                })
            });

            const data = await response.json();

            if (response.ok) {
                // Successful login
                const userName = email.split('@')[0];
                sessionStorage.setItem('userName', userName);
                sessionStorage.setItem('userEmail', email);
                
                // Show welcome message
                alert(`Welcome to Agri Storage, ${userName}!`);
                
                // Hide auth section and show dashboard
                document.getElementById('authSection').classList.add('hidden');
                document.getElementById('navbar').classList.remove('hidden');
                document.getElementById('dashboardContainer').classList.remove('hidden');
                document.getElementById('welcomeUser').textContent = `Welcome, ${userName}`;
                
                // Initialize dashboard
                initializeDashboard();
            } else {
                alert(data.error || 'Invalid OTP. Please try again.');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error. Please check your connection.');
        }
    });

    // Handle Register Form Submission
    document.getElementById('registerFormElement').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const phone = document.getElementById('registerPhone').value;
        const enteredOTP = document.getElementById('registerOTP').value;

        try {
            // First verify OTP
            const verifyResponse = await fetch(`${API_BASE_URL}/verify-otp`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: email,
                    otp: enteredOTP
                })
            });

            const verifyData = await verifyResponse.json();

            if (verifyResponse.ok) {
                // OTP verified, now register
                const registerResponse = await fetch(`${API_BASE_URL}/register-farmer`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        name: name,
                        email: email,
                        phone: phone
                    })
                });

                const registerData = await registerResponse.json();

                if (registerResponse.ok) {
                    alert(`Welcome to Agri Storage, ${name}! Registration successful.`);
                    
                    sessionStorage.setItem('userName', name);
                    sessionStorage.setItem('userEmail', email);
                    sessionStorage.setItem('userPhone', phone);
                    
                    document.getElementById('authSection').classList.add('hidden');
                    document.getElementById('navbar').classList.remove('hidden');
                    document.getElementById('dashboardContainer').classList.remove('hidden');
                    document.getElementById('welcomeUser').textContent = `Welcome, ${name}`;
                    
                    initializeDashboard();
                } else {
                    alert(registerData.error || 'Registration failed');
                }
            } else {
                alert(verifyData.error || 'Invalid OTP');
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Network error. Please check your connection.');
        }
    });

    // Logout
    document.getElementById('logoutBtn').addEventListener('click', function() {
        sessionStorage.clear();
        location.reload();
    });

    // Initialize Dashboard (same as before)
    function initializeDashboard() {
        // Your existing dashboard initialization code
        const dashboardContainer = document.getElementById('dashboardContainer');
        
        dashboardContainer.innerHTML = `
            <div class="dashboard-content">
                <div class="dashboard-header">
                    <h2>Farmer Dashboard</h2>
                    <div class="voice-command">
                        <button class="btn btn-secondary" id="voiceCommandBtn">
                            <i class="fas fa-microphone"></i> Voice Command
                        </button>
                    </div>
                </div>
                
                <div class="quick-stats">
                    <div class="stat-card">
                        <i class="fas fa-warehouse"></i>
                        <h3>24</h3>
                        <p>Nearby Storages</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-chart-line"></i>
                        <h3>₹2,500/q</h3>
                        <p>Market Price (Rice)</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-calendar-check"></i>
                        <h3>3</h3>
                        <p>Active Bookings</p>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-rupee-sign"></i>
                        <h3>15%</h3>
                        <p>Price Increase</p>
                    </div>
                </div>
                
                <div class="search-section">
                    <h3>Find Cold Storage</h3>
                    <div class="search-form">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="cropType">Crop Type</label>
                                <select id="cropType">
                                    <option value="">Select Crop</option>
                                    <option value="rice">Rice</option>
                                    <option value="wheat">Wheat</option>
                                    <option value="vegetables">Vegetables</option>
                                    <option value="fruits">Fruits</option>
                                    <option value="chillies">Chillies</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="quantity">Quantity (kg)</label>
                                <input type="number" id="quantity" placeholder="Enter quantity">
                            </div>
                            <div class="form-group">
                                <label for="location">Your Location</label>
                                <select id="location">
                                    <option value="">Select District</option>
                                    <option value="guntur">Guntur</option>
                                    <option value="krishna">Krishna</option>
                                    <option value="prakasam">Prakasam</option>
                                    <option value="chittoor">Chittoor</option>
                                    <option value="anantapur">Anantapur</option>
                                </select>
                            </div>
                        </div>
                        <button class="btn btn-primary" id="searchStorage">Find Storage</button>
                    </div>
                </div>
                
                <div class="storage-results" id="storageResults"></div>
                
                <div class="trends-section">
                    <h3>Market Trends</h3>
                    <div class="trends-grid" id="trendsGrid"></div>
                </div>
                
                <div class="language-selector">
                    <select id="languageSelect">
                        <option value="en">English</option>
                        <option value="te">తెలుగు</option>
                        <option value="hi">हिन्दी</option>
                        <option value="ta">தமிழ்</option>
                        <option value="kn">ಕನ್ನಡ</option>
                    </select>
                </div>
            </div>
        `;

        loadStorageFacilities();
        loadMarketTrends();
        initializeVoiceCommand();
        initializeLanguageSelector();
    }

    // Load Storage Facilities
    function loadStorageFacilities() {
        const storageData = [
            {
                id: 1,
                name: "Guntur Chillies Cold Storage",
                location: "Chilakaluripet, Guntur",
                distance: "5 km",
                capacity: "50,000 kg",
                available: "30,000 kg",
                temperature: "8°C to 12°C",
                price: "₹3.50/kg/month",
                rating: 4,
                contact: "08645-223344"
            },
            {
                id: 2,
                name: "Krishna Banana Cold Chain",
                location: "Machilipatnam, Krishna",
                distance: "12 km",
                capacity: "75,000 kg",
                available: "20,000 kg",
                temperature: "12°C to 15°C",
                price: "₹4.00/kg/month",
                rating: 5,
                contact: "08676-334455"
            }
        ];

        const resultsContainer = document.getElementById('storageResults');
        resultsContainer.innerHTML = '<h4>Nearby Storage Facilities</h4>';
        
        storageData.forEach(storage => {
            const stars = '★'.repeat(storage.rating) + '☆'.repeat(5 - storage.rating);
            
            resultsContainer.innerHTML += `
                <div class="storage-card">
                    <div class="storage-info">
                        <h5>${storage.name}</h5>
                        <p><i class="fas fa-map-marker-alt"></i> ${storage.location} (${storage.distance})</p>
                        <p><i class="fas fa-weight-hanging"></i> Available: ${storage.available}</p>
                        <p><i class="fas fa-temperature-low"></i> ${storage.temperature}</p>
                        <p><i class="fas fa-tag"></i> ${storage.price}</p>
                        <p><i class="fas fa-star"></i> ${stars}</p>
                        <p><i class="fas fa-phone"></i> ${storage.contact}</p>
                    </div>
                    <button class="btn btn-primary book-storage" data-id="${storage.id}">Book Now</button>
                </div>
            `;
        });
    }

    // Load Market Trends
    function loadMarketTrends() {
        const trendsData = [
            { crop: "Rice", price: "₹2,500/q", change: "+5%", trend: "up" },
            { crop: "Wheat", price: "₹2,200/q", change: "+3%", trend: "up" },
            { crop: "Chillies", price: "₹14,500/q", change: "+8%", trend: "up" },
            { crop: "Groundnut", price: "₹6,200/q", change: "-2%", trend: "down" }
        ];

        const trendsGrid = document.getElementById('trendsGrid');
        
        trendsData.forEach(trend => {
            trendsGrid.innerHTML += `
                <div class="trend-card ${trend.trend}">
                    <h4>${trend.crop}</h4>
                    <p class="price">${trend.price}</p>
                    <p class="change ${trend.trend}">
                        <i class="fas fa-${trend.trend === 'up' ? 'arrow-up' : 'arrow-down'}"></i>
                        ${trend.change}
                    </p>
                </div>
            `;
        });
    }

    // Voice Command Functionality
    function initializeVoiceCommand() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            const recognition = new SpeechRecognition();
            
            recognition.continuous = false;
            recognition.lang = 'en-US';
            recognition.interimResults = false;

            document.getElementById('voiceCommandBtn').addEventListener('click', function() {
                recognition.start();
                this.innerHTML = '<i class="fas fa-microphone-alt"></i> Listening...';
            });

            recognition.onresult = function(event) {
                const command = event.results[0][0].transcript.toLowerCase();
                document.getElementById('voiceCommandBtn').innerHTML = '<i class="fas fa-microphone"></i> Voice Command';
                
                if (command.includes('find storage')) {
                    document.getElementById('searchStorage').click();
                } else if (command.includes('market price')) {
                    alert('Showing market prices');
                }
            };
        }
    }

    // Language Selector
    function initializeLanguageSelector() {
        document.getElementById('languageSelect').addEventListener('change', function(e) {
            const lang = e.target.value;
            // Implement language change logic here
            console.log('Language changed to:', lang);
        });
    }
});