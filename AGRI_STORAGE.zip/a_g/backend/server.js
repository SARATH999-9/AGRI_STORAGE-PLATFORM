const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Store OTPs temporarily (in production, use Redis or database)
const otpStore = new Map();

// Email configuration
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'sarathchandranimmakayala@gmail.com',
        pass: 'ozfx nplm drff ysip' // Your app password
    }
});

// Verify email connection
transporter.verify((error, success) => {
    if (error) {
        console.log('Email connection error:', error);
    } else {
        console.log('Email server is ready to send messages');
    }
});

// Generate OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP endpoint
app.post('/api/send-otp', async (req, res) => {
    try {
        const { email, purpose } = req.body;
        
        if (!email) {
            return res.status(400).json({ error: 'Email is required' });
        }

        const otp = generateOTP();
        
        // Store OTP with timestamp (expires in 10 minutes)
        otpStore.set(email, {
            otp,
            timestamp: Date.now(),
            attempts: 0
        });

        // Email content
        const mailOptions = {
            from: '"Agri Storage" <sarathchandranimmakayala@gmail.com>',
            to: email,
            subject: `OTP for ${purpose} - Agri Storage`,
            html: `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            margin: 0;
                            padding: 0;
                        }
                        .container {
                            max-width: 600px;
                            margin: 20px auto;
                            background: white;
                            border-radius: 15px;
                            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
                            overflow: hidden;
                        }
                        .header {
                            background: linear-gradient(135deg, #2E7D32, #4CAF50);
                            padding: 30px;
                            text-align: center;
                        }
                        .header h1 {
                            color: white;
                            margin: 0;
                            font-size: 28px;
                        }
                        .content {
                            padding: 40px 30px;
                            text-align: center;
                        }
                        .otp-code {
                            background: linear-gradient(135deg, #f5f7fa, #e8f5e9);
                            padding: 20px;
                            border-radius: 10px;
                            margin: 20px 0;
                        }
                        .otp-code h2 {
                            font-size: 48px;
                            color: #2E7D32;
                            letter-spacing: 10px;
                            margin: 0;
                        }
                        .footer {
                            background: #f8f9fa;
                            padding: 20px;
                            text-align: center;
                            color: #666;
                        }
                        .btn {
                            background: linear-gradient(135deg, #2E7D32, #4CAF50);
                            color: white;
                            padding: 12px 30px;
                            text-decoration: none;
                            border-radius: 25px;
                            display: inline-block;
                            margin-top: 20px;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>🌾 Agri Storage</h1>
                        </div>
                        <div class="content">
                            <h2>Hello Farmer!</h2>
                            <p>You requested an OTP for <strong>${purpose}</strong></p>
                            <div class="otp-code">
                                <h2>${otp}</h2>
                            </div>
                            <p>This OTP is valid for 10 minutes. Please do not share it with anyone.</p>
                            <p>If you didn't request this, please ignore this email.</p>
                            <a href="#" class="btn">Visit Agri Storage</a>
                        </div>
                        <div class="footer">
                            <p>&copy; 2024 Agri Storage - Made by Sparks</p>
                            <p>Empowering Farmers with Smart Storage Solutions</p>
                        </div>
                    </div>
                </body>
                </html>
            `
        };

        // Send email
        await transporter.sendMail(mailOptions);
        
        console.log(`OTP sent to ${email}: ${otp}`); // For debugging
        
        res.json({ 
            success: true, 
            message: 'OTP sent successfully',
            email: email 
        });

    } catch (error) {
        console.error('Error sending OTP:', error);
        res.status(500).json({ error: 'Failed to send OTP' });
    }
});

// Verify OTP endpoint
app.post('/api/verify-otp', (req, res) => {
    try {
        const { email, otp } = req.body;

        if (!email || !otp) {
            return res.status(400).json({ error: 'Email and OTP are required' });
        }

        const storedData = otpStore.get(email);

        if (!storedData) {
            return res.status(400).json({ error: 'No OTP found for this email' });
        }

        // Check if OTP expired (10 minutes)
        const timeDiff = Date.now() - storedData.timestamp;
        if (timeDiff > 10 * 60 * 1000) {
            otpStore.delete(email);
            return res.status(400).json({ error: 'OTP expired' });
        }

        // Check attempts
        storedData.attempts++;
        if (storedData.attempts > 3) {
            otpStore.delete(email);
            return res.status(400).json({ error: 'Too many failed attempts' });
        }

        if (storedData.otp === otp) {
            // OTP verified successfully
            otpStore.delete(email);
            res.json({ 
                success: true, 
                message: 'OTP verified successfully',
                email: email
            });
        } else {
            res.status(400).json({ error: 'Invalid OTP' });
        }

    } catch (error) {
        console.error('Error verifying OTP:', error);
        res.status(500).json({ error: 'Failed to verify OTP' });
    }
});

// Register farmer endpoint
app.post('/api/register-farmer', (req, res) => {
    try {
        const { name, email, phone } = req.body;
        
        // In production, save to database
        console.log('Farmer registered:', { name, email, phone });
        
        // Send welcome email
        const welcomeMailOptions = {
            from: '"Agri Storage" <sarathchandranimmakayala@gmail.com>',
            to: email,
            subject: 'Welcome to Agri Storage Family!',
            html: `
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { font-family: Arial, sans-serif; }
                        .container { max-width: 600px; margin: 20px auto; }
                        .header { background: linear-gradient(135deg, #2E7D32, #4CAF50); color: white; padding: 30px; text-align: center; }
                        .content { padding: 30px; background: #f9f9f9; }
                        .footer { background: #333; color: white; padding: 20px; text-align: center; }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <div class="header">
                            <h1>Welcome to Agri Storage, ${name}!</h1>
                        </div>
                        <div class="content">
                            <h2>Dear Farmer,</h2>
                            <p>Thank you for joining Agri Storage! We're here to help you maximize your profits through smart storage solutions.</p>
                            <h3>What you can do:</h3>
                            <ul>
                                <li>Find nearby cold storage facilities</li>
                                <li>Check real-time market trends</li>
                                <li>Get expert farming guidance</li>
                                <li>Use voice commands in your language</li>
                            </ul>
                            <p>Start exploring your dashboard now!</p>
                        </div>
                        <div class="footer">
                            <p>Made by Sparks - Empowering Farmers</p>
                        </div>
                    </div>
                </body>
                </html>
            `
        };

        transporter.sendMail(welcomeMailOptions).catch(console.error);

        res.json({ 
            success: true, 
            message: 'Registration successful',
            user: { name, email, phone }
        });

    } catch (error) {
        console.error('Error registering farmer:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});