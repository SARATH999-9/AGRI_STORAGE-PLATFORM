document.addEventListener('DOMContentLoaded', function() {
    // Mobile Navigation Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    hamburger.addEventListener('click', function() {
        navLinks.classList.toggle('active');
        this.querySelector('i').classList.toggle('fa-times');
        this.querySelector('i').classList.toggle('fa-bars');
    });
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            hamburger.querySelector('i').classList.remove('fa-times');
            hamburger.querySelector('i').classList.add('fa-bars');
        });
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Navbar scroll effect
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Andhra Pradesh Cold Storage Data
    const storageFacilities = [
        {
            id: 1,
            name: "Guntur Chillies Cold Storage",
            location: "Chilakaluripet, Guntur, Andhra Pradesh",
            distance: "5 km",
            capacity: "50,000 kg",
            available: "30,000 kg",
            temperature: "8°C to 12°C",
            price: "₹3.50/kg/month",
            rating: 4,
            crops: ["Red Chillies", "Turmeric", "Onions"],
            image: "https://i.ytimg.com/vi/RwEBE6QKTYQ/maxresdefault.jpg",
            description: "Specialized in storing spices with humidity-controlled chambers. Established in 2015 with modern refrigeration technology.",
            contact: "091234 56789",
            email: "gunturcold@example.com",
            features: ["24/7 monitoring", "Humidity control", "Pest-free environment", "Loading/unloading assistance"],
            storageTypes: [
                { type: "Bulk Storage", capacity: "30,000 kg" },
                { type: "Pallet Racking", capacity: "15,000 kg" },
                { type: "Controlled Atmosphere", capacity: "5,000 kg" }
            ],
            operatingHours: "Mon-Sat: 8AM-8PM, Sun: 9AM-4PM"
        },
        {
            id: 2,
            name: "Krishna Banana Cold Chain",
            location: "Machilipatnam, Krishna, Andhra Pradesh",
            distance: "12 km",
            capacity: "75,000 kg",
            available: "20,000 kg",
            temperature: "12°C to 15°C",
            price: "₹4.00/kg/month",
            rating: 5,
            crops: ["Bananas", "Mangoes", "Papayas"],
            image: "https://5.imimg.com/data5/SELLER/Default/2023/10/352854852/NQ/IZ/VA/189392038/banana-ripening-chamber-500x500.png",
            description: "Specialized ripening and cold storage facility for fruits with ethylene gas control systems.",
            contact: "098765 43210",
            email: "krishnabanana@example.com",
            features: ["Ethylene control", "Ripening chambers", "Grading facility", "Packaging services"],
            storageTypes: [
                { type: "Ripening Chambers", capacity: "25,000 kg" },
                { type: "Long-term Storage", capacity: "50,000 kg" }
            ],
            operatingHours: "Mon-Sun: 7AM-9PM"
        },
        {
            id: 3,
            name: "Prakasam Agri Cold Storage",
            location: "Ongole, Prakasam, Andhra Pradesh",
            distance: "8 km",
            capacity: "30,000 kg",
            available: "15,000 kg",
            temperature: "2°C to 8°C",
            price: "₹3.75/kg/month",
            rating: 4,
            crops: ["Tomatoes", "Leafy Greens", "Vegetables"],
            image: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
            description: "Vegetable-specific cold storage with pre-cooling facilities to extend shelf life.",
            contact: "087654 32109",
            email: "prakasamagri@example.com",
            features: ["Pre-cooling tunnels", "Wash facilities", "Sorting area", "Daily quality checks"],
            storageTypes: [
                { type: "Refrigerated Containers", capacity: "10,000 kg" },
                { type: "Walk-in Cold Rooms", capacity: "20,000 kg" }
            ],
            operatingHours: "Mon-Sat: 7AM-7PM, Sun: Closed"
        },
        {
            id: 4,
            name: "Chittoor Mango Cold Storage",
            location: "Madanapalle, Chittoor, Andhra Pradesh",
            distance: "15 km",
            capacity: "100,000 kg",
            available: "40,000 kg",
            temperature: "10°C to 14°C",
            price: "₹4.25/kg/month",
            rating: 4,
            crops: ["Mangoes", "Oranges", "Grapes"],
            image: "https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
            description: "Largest mango storage facility in the region with export-grade packaging services.",
            contact: "076543 21098",
            email: "chittoormango@example.com",
            features: ["Export packaging", "Quality certification", "Cold chain logistics", "Fumigation services"],
            storageTypes: [
                { type: "Controlled Atmosphere", capacity: "40,000 kg" },
                { type: "Conventional Storage", capacity: "60,000 kg" }
            ],
            operatingHours: "Mon-Sun: 6AM-10PM (Seasonal)"
        },
        {
            id: 5,
            name: "Anantapur Groundnut Storage",
            location: "Dharmavaram, Anantapur, Andhra Pradesh",
            distance: "7 km",
            capacity: "40,000 kg",
            available: "25,000 kg",
            temperature: "15°C to 18°C",
            price: "₹3.90/kg/month",
            rating: 3,
            crops: ["Groundnuts", "Sunflower Seeds", "Pulses"],
            image: "https://i.ytimg.com/vi/tmw0DHiwCgo/maxresdefault.jpg",
            description: "Dry storage facility specializing in oilseeds and pulses with moisture control.",
            contact: "065432 10987",
            email: "anantapurstorage@example.com",
            features: ["Moisture control", "Fumigation", "Bulk handling", "Aeration systems"],
            storageTypes: [
                { type: "Silo Storage", capacity: "25,000 kg" },
                { type: "Bag Storage", capacity: "15,000 kg" }
            ],
            operatingHours: "Mon-Sat: 8AM-6PM"
        },
        {
            id: 6,
            name: "Nellore Rice Cold Storage",
            location: "Kavali, Nellore, Andhra Pradesh",
            distance: "10 km",
            capacity: "80,000 kg",
            available: "35,000 kg",
            temperature: "15°C to 20°C",
            price: "₹3.20/kg/month",
            rating: 4,
            crops: ["Rice", "Wheat", "Millets"],
            image: "https://th-i.thgim.com/public/news/national/andhra-pradesh/article19612493.ece/alternates/LANDSCAPE_1200/03VJNLRICE",
            description: "Government-approved storage for grains with pest control and quality monitoring.",
            contact: "054321 09876",
            email: "nellorerice@example.com",
            features: ["Pest control", "Quality testing", "Weighbridge", "Government certified"],
            storageTypes: [
                { type: "Bulk Storage", capacity: "50,000 kg" },
                { type: "Bag Storage", capacity: "30,000 kg" }
            ],
            operatingHours: "Mon-Sun: 6AM-8PM"
        }
    ];
    
    // Function to render storage facilities
    function renderStorageFacilities(facilities) {
        const resultsGrid = document.querySelector('.results-grid');
        resultsGrid.innerHTML = '';
        
        if (facilities.length === 0) {
            resultsGrid.innerHTML = '<p class="no-results">No storage facilities found matching your criteria.</p>';
            return;
        }
        
        facilities.forEach(facility => {
            const stars = '★'.repeat(facility.rating) + '☆'.repeat(5 - facility.rating);
            
            const facilityCard = document.createElement('div');
            facilityCard.className = 'storage-card';
            facilityCard.innerHTML = `
                <div class="storage-card-img">
                    <img src="${facility.image}" alt="${facility.name}">
                </div>
                <div class="storage-card-content">
                    <h3 class="storage-card-title">${facility.name}</h3>
                    <div class="storage-card-location">
                        <i class="fas fa-map-marker-alt"></i> ${facility.location} (${facility.distance})
                    </div>
                    <div class="storage-card-specs">
                        <div class="storage-card-spec">
                            <i class="fas fa-weight-hanging"></i> ${facility.available} available
                        </div>
                        <div class="storage-card-spec">
                            <i class="fas fa-temperature-low"></i> ${facility.temperature}
                        </div>
                    </div>
                    <div class="storage-card-specs">
                        <div class="storage-card-spec">
                            <i class="fas fa-crop-alt"></i> ${facility.crops.join(', ')}
                        </div>
                        <div class="storage-card-spec">
                            <i class="fas fa-star"></i> ${stars}
                        </div>
                    </div>
                    <div class="storage-card-price">${facility.price}</div>
                    <button class="btn btn-primary storage-card-btn view-details" data-id="${facility.id}">View Details</button>
                </div>
            `;
            
            resultsGrid.appendChild(facilityCard);
        });
        
        // Add event listeners to view details buttons
        document.querySelectorAll('.view-details').forEach(button => {
            button.addEventListener('click', function() {
                const facilityId = parseInt(this.getAttribute('data-id'));
                const facility = storageFacilities.find(f => f.id === facilityId);
                if (facility) {
                    showFacilityDetails(facility);
                }
            });
        });
    }
    
    // Function to show comprehensive facility details in modal
    function showFacilityDetails(facility) {
        const modal = document.getElementById('storage-modal');
        const stars = '★'.repeat(facility.rating) + '☆'.repeat(5 - facility.rating);
        
        // Basic information
        document.getElementById('modal-facility-name').textContent = facility.name;
        document.getElementById('modal-facility-image').src = facility.image;
        document.getElementById('modal-facility-image').alt = facility.name;
        
        // Facility details section
        const detailsContent = document.getElementById('modal-details-content');
        detailsContent.innerHTML = `
            <div class="details-section">
                <h3><i class="fas fa-info-circle"></i> Facility Overview</h3>
                <div class="detail-row">
                    <div class="detail-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Location</h4>
                            <p>${facility.location}</p>
                        </div>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-phone-alt"></i>
                        <div>
                            <h4>Contact</h4>
                            <p>${facility.contact}</p>
                        </div>
                    </div>
                </div>
                
                <div class="detail-row">
                    <div class="detail-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>${facility.email}</p>
                        </div>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Operating Hours</h4>
                            <p>${facility.operatingHours}</p>
                        </div>
                    </div>
                </div>
                
                <div class="detail-description">
                    <h4>Description</h4>
                    <p>${facility.description}</p>
                </div>
                
                <div class="detail-features">
                    <h4>Key Features</h4>
                    <ul>
                        ${facility.features.map(feature => `<li><i class="fas fa-check-circle"></i> ${feature}</li>`).join('')}
                    </ul>
                </div>
            </div>
            
            <div class="details-section">
                <h3><i class="fas fa-warehouse"></i> Storage Specifications</h3>
                <div class="specs-grid">
                    <div class="spec-card">
                        <i class="fas fa-thermometer-half"></i>
                        <h4>Temperature Range</h4>
                        <p>${facility.temperature}</p>
                    </div>
                    <div class="spec-card">
                        <i class="fas fa-weight-hanging"></i>
                        <h4>Total Capacity</h4>
                        <p>${facility.capacity}</p>
                    </div>
                    <div class="spec-card">
                        <i class="fas fa-box-open"></i>
                        <h4>Available Space</h4>
                        <p>${facility.available}</p>
                    </div>
                    <div class="spec-card">
                        <i class="fas fa-money-bill-wave"></i>
                        <h4>Storage Price</h4>
                        <p>${facility.price}</p>
                    </div>
                </div>
                
                <div class="storage-types">
                    <h4>Storage Types Available</h4>
                    <div class="types-grid">
                        ${facility.storageTypes.map(type => `
                            <div class="type-card">
                                <h5>${type.type}</h5>
                                <p>Capacity: ${type.capacity}</p>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="crops-supported">
                    <h4>Crops Supported</h4>
                    <div class="crops-tags">
                        ${facility.crops.map(crop => `<span class="crop-tag">${crop}</span>`).join('')}
                    </div>
                </div>
            </div>
            
            <div class="details-section">
                <h3><i class="fas fa-star"></i> Ratings & Reviews</h3>
                <div class="rating-display">
                    <div class="stars">${stars}</div>
                    <div class="rating-text">${facility.rating} out of 5 stars</div>
                </div>
                <div class="reviews">
                    <div class="review">
                        <div class="review-author">Ramesh K.</div>
                        <div class="review-stars">★★★★☆</div>
                        <div class="review-text">"Good facility for chilli storage. Maintains proper temperature."</div>
                    </div>
                    <div class="review">
                        <div class="review-author">Suresh P.</div>
                        <div class="review-stars">★★★★★</div>
                        <div class="review-text">"Excellent service. My bananas were stored perfectly for 2 months."</div>
                    </div>
                </div>
            </div>
        `;
        
        // Pre-fill booking form with facility info
        document.getElementById('booking-facility-name').value = facility.name;
        document.getElementById('booking-facility-location').value = facility.location;
        
        // Show the modal
        modal.classList.add('active');
    }
    
    // Close modal
    document.querySelector('.close-modal').addEventListener('click', function() {
        document.getElementById('storage-modal').classList.remove('active');
    });
    
    // Close modal when clicking outside
    document.getElementById('storage-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('active');
        }
    });
    
    // Search functionality
    document.querySelector('.search-btn').addEventListener('click', function() {
        const location = document.getElementById('location').value;
        const cropType = document.getElementById('crop-type').value;
        const capacity = parseInt(document.getElementById('capacity').value) || 0;
        
        let filteredFacilities = storageFacilities;
        
        if (location) {
            filteredFacilities = filteredFacilities.filter(f => 
                f.location.toLowerCase().includes(location.toLowerCase()));
        }
        
        if (cropType) {
            filteredFacilities = filteredFacilities.filter(f => 
                f.crops.some(crop => crop.toLowerCase().includes(cropType.toLowerCase())));
        }
        
        if (capacity > 0) {
            filteredFacilities = filteredFacilities.filter(f => {
                const available = parseInt(f.available.replace(/,/g, ''));
                return available >= capacity;
            });
        }
        
        renderStorageFacilities(filteredFacilities);
    });
    
    // Sort functionality
    document.getElementById('sort-by').addEventListener('change', function() {
        const sortBy = this.value;
        let sortedFacilities = [...storageFacilities];
        
        switch(sortBy) {
            case 'distance':
                sortedFacilities.sort((a, b) => {
                    const aDist = parseInt(a.distance.split(' ')[0]);
                    const bDist = parseInt(b.distance.split(' ')[0]);
                    return aDist - bDist;
                });
                break;
            case 'price':
                sortedFacilities.sort((a, b) => {
                    const aPrice = parseFloat(a.price.replace(/[^0-9.]/g, ''));
                    const bPrice = parseFloat(b.price.replace(/[^0-9.]/g, ''));
                    return aPrice - bPrice;
                });
                break;
            case 'rating':
                sortedFacilities.sort((a, b) => b.rating - a.rating);
                break;
            case 'capacity':
                sortedFacilities.sort((a, b) => {
                    const aCap = parseInt(a.available.replace(/,/g, ''));
                    const bCap = parseInt(b.available.replace(/,/g, ''));
                    return bCap - aCap;
                });
                break;
        }
        
        renderStorageFacilities(sortedFacilities);
    });
    
    // Initialize with all facilities
    renderStorageFacilities(storageFacilities);
    
    // Form submission handlers
    document.querySelector('.booking-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = document.getElementById('booking-name').value;
        const contact = document.getElementById('booking-contact').value;
        const crop = document.getElementById('booking-crop').value;
        const quantity = document.getElementById('booking-quantity').value;
        const duration = document.getElementById('booking-duration').value;
        
        // Simple validation
        if (!name || !contact || !crop || !quantity || !duration) {
            alert('Please fill all required fields');
            return;
        }
        
        // Show confirmation
        const facilityName = document.getElementById('booking-facility-name').value;
        alert(`Booking request submitted successfully for ${facilityName}!\n\nWe will contact you shortly at ${contact} to confirm your ${quantity}kg of ${crop} for ${duration} months.`);
        
        // Close modal and reset form
        document.getElementById('storage-modal').classList.remove('active');
        this.reset();
    });
    
    document.querySelector('.contact-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for your message! We will get back to you soon.');
        this.reset();
    });
    
    document.querySelector('.newsletter-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Thank you for subscribing to our newsletter!');
        this.reset();
    });
});