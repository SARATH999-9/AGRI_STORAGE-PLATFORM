/* ═══════════════════════════════════════════════════════════════════════
   KISAN STORAGE PRO  v3.0  —  main.js
   All-in-one: Splash · Auth · OTP · Voice Assistant (TTS+STT) · Pages
   Multilingual: English · Hindi · Telugu · Tamil · Kannada ·
                 Malayalam · Marathi · Gujarati · Punjabi · Bengali
═══════════════════════════════════════════════════════════════════════ */

'use strict';

/* ───────────────────────────────────────────────────────────────────────
   1. API LAYER
─────────────────────────────────────────────────────────────────────── */
const Api = (() => {
  const BASE = '/api';
  let _token = localStorage.getItem('ks_token') || null;

  const setToken = t => { _token = t; t ? localStorage.setItem('ks_token', t) : localStorage.removeItem('ks_token'); };
  const getToken = () => _token;

  const req = async (method, path, body) => {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (_token) opts.headers['Authorization'] = 'Bearer ' + _token;
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(BASE + path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  };

  return {
    setToken, getToken,
    get:   (p)    => req('GET',   p),
    post:  (p, b) => req('POST',  p, b),
    put:   (p, b) => req('PUT',   p, b),
    patch: (p, b) => req('PATCH', p, b),
    /* Auth */
    login:    (phone, password) => req('POST', '/auth/login',    { phone, password }),
    register: (name, phone, location, password) => req('POST', '/auth/register', { name, phone, location, password }),
    guest:    ()                => req('POST', '/auth/guest',    {}),
    me:       ()                => req('GET',  '/auth/me'),
    /* OTP */
    sendOtp:   (email)      => req('POST', '/otp/send',   { email }),
    verifyOtp: (email, otp) => req('POST', '/otp/verify', { email, otp }),
    /* Data */
    facilities: (q = {}) => { const s = new URLSearchParams(q).toString(); return req('GET', '/facilities' + (s ? '?' + s : '')); },
    facility:   (id)     => req('GET', '/facilities/' + id),
    market:     ()       => req('GET', '/market'),
    bookings:   ()       => req('GET', '/bookings'),
    createBooking: d     => req('POST', '/bookings', d),
    cancelBooking: id    => req('PATCH', '/bookings/' + id + '/cancel', {}),
  };
})();

/* ───────────────────────────────────────────────────────────────────────
   2. UTILITY HELPERS
─────────────────────────────────────────────────────────────────────── */
const $ = id => document.getElementById(id);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };

let _toastTimer = null;
const toast = (msg, isErr = false) => {
  const t = $('toast');
  t.textContent = msg;
  t.className = isErr ? 'err' : '';
  t.style.display = 'flex';
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { t.style.display = 'none'; }, 3600);
};

const spinner = () => '<span class="spin"></span>';
const fmt = d => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
const stars = n => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));

/* ───────────────────────────────────────────────────────────────────────
   3. SPLASH  (SPARKS animation then reveal app)
─────────────────────────────────────────────────────────────────────── */
const Splash = {
  run() {
    // Letters animate via CSS. We watch for the animation to complete.
    // Total splash: MADE BY fades (.8s@.2s) + bar (.8s@1.5s) + subtitle (.6s@2s)
    // We hide splash at 3.8s and show app at 4s
    setTimeout(() => {
      const splash = $('splash');
      splash.style.transition = 'opacity 0.8s ease, visibility 0.8s ease';
      splash.style.opacity    = '0';
      splash.style.visibility = 'hidden';
    }, 3600);

    setTimeout(() => {
      $('splash').remove();
      $('app').classList.remove('hidden');
      Auth.init();
    }, 4200);
  },
};

/* ───────────────────────────────────────────────────────────────────────
   4. VOICE ASSISTANT  (STT + TTS, multilingual)
─────────────────────────────────────────────────────────────────────── */
const VA = (() => {
  /* ── Language response strings ─────────────────────────── */
  const LANG_DATA = {
    'en-IN': {
      welcome:      n  => `Welcome to Kisan Agri Storage, ${n}! I'll guide you. Say Home, Storage, Market, or Bookings to navigate.`,
      page_home:    () => 'Opening Home page. Here you can see market prices and nearby facilities.',
      page_storage: () => 'Opening Storage Directory. Find cold storage facilities near you.',
      page_market:  () => 'Opening Market Prices. Check live mandi rates and selling advice.',
      page_bookings:() => 'Opening My Bookings. View and manage your storage reservations.',
      help:         () => 'I can navigate pages for you. Say Home, Storage, Market, Bookings, or ask for Price of any crop.',
      price_info:   (c,p) => `Current ${c} price is ₹${p} per quintal.`,
      theme_dark:   () => 'Switched to dark mode.',
      theme_light:  () => 'Switched to light mode.',
      logout:       () => 'Logging you out. Thank you for using Kisan Storage!',
      not_found:    () => "Sorry, I didn't catch that. Try saying Home, Storage, Market, or Bookings.",
      listening:    () => 'Listening...',
      examples:     () => '"Go to market", "Show storage", "Rice price", "My bookings"',
    },
    'hi-IN': {
      welcome:      n  => `कृषि भंडारण में आपका स्वागत है, ${n}! होम, भंडारण, बाजार या बुकिंग बोलकर नेविगेट करें।`,
      page_home:    () => 'होम पेज खुल रहा है।',
      page_storage: () => 'भंडारण सूची खुल रही है।',
      page_market:  () => 'बाजार भाव दिखाए जा रहे हैं।',
      page_bookings:() => 'आपकी बुकिंग दिखाई जा रही है।',
      help:         () => 'मैं होम, भंडारण, बाजार या बुकिंग पर जा सकता हूं।',
      price_info:   (c,p) => `${c} की मौजूदा कीमत ₹${p} प्रति क्विंटल है।`,
      theme_dark:   () => 'डार्क मोड चालू।',
      theme_light:  () => 'लाइट मोड चालू।',
      logout:       () => 'लॉग आउट हो रहे हैं। धन्यवाद!',
      not_found:    () => 'माफ़ कीजिए, समझ नहीं आया। फिर से बोलें।',
      listening:    () => 'सुन रहा हूं...',
      examples:     () => '"बाजार जाओ", "भंडारण दिखाओ", "चावल दाम", "मेरी बुकिंग"',
    },
    'te-IN': {
      welcome:      n  => `వ్యవసాయ నిల్వకు స్వాగతం, ${n}! హోమ్, స్టోరేజ్, మార్కెట్ లేదా బుకింగ్ అని చెప్పండి.`,
      page_home:    () => 'హోమ్ పేజీ తెరుస్తున్నాం.',
      page_storage: () => 'స్టోరేజ్ డైరెక్టరీ తెరుస్తున్నాం.',
      page_market:  () => 'మార్కెట్ ధరలు చూపిస్తున్నాం.',
      page_bookings:() => 'మీ బుకింగ్‌లు చూపిస్తున్నాం.',
      help:         () => 'హోమ్, స్టోరేజ్, మార్కెట్ లేదా బుకింగ్ అని చెప్పండి.',
      price_info:   (c,p) => `${c} ప్రస్తుత ధర ₹${p} క్వింటాలుకు.`,
      theme_dark:   () => 'డార్క్ మోడ్ ఆన్.',
      theme_light:  () => 'లైట్ మోడ్ ఆన్.',
      logout:       () => 'లాగ్ అవుట్ అవుతున్నారు. ధన్యవాదాలు!',
      not_found:    () => 'క్షమించండి, అర్థం కాలేదు. మళ్ళీ చెప్పండి.',
      listening:    () => 'వింటున్నాను...',
      examples:     () => '"మార్కెట్ వెళ్ళు", "స్టోరేజ్ చూపించు", "వరి ధర", "నా బుకింగ్"',
    },
    'ta-IN': {
      welcome:      n  => `வேளாண் சேமிப்பிற்கு வரவேற்கிறோம், ${n}! முகப்பு, சேமிப்பு, சந்தை என்று சொல்லுங்கள்.`,
      page_home:    () => 'முகப்பு பக்கம் திறக்கிறோம்.',
      page_storage: () => 'சேமிப்பு பட்டியல் திறக்கிறோம்.',
      page_market:  () => 'சந்தை விலைகள் காட்டுகிறோம்.',
      page_bookings:() => 'உங்கள் முன்பதிவுகள் காட்டுகிறோம்.',
      help:         () => 'முகப்பு, சேமிப்பு, சந்தை, முன்பதிவு என்று சொல்லுங்கள்.',
      price_info:   (c,p) => `${c} தற்போதைய விலை ₹${p} குவிண்டாலுக்கு.`,
      theme_dark:   () => 'இருண்ட பயன்முறை.',
      theme_light:  () => 'ஒளி பயன்முறை.',
      logout:       () => 'வெளியேறுகிறீர்கள். நன்றி!',
      not_found:    () => 'மன்னிக்கவும், புரியவில்லை. மீண்டும் சொல்லுங்கள்.',
      listening:    () => 'கேட்கிறேன்...',
      examples:     () => '"சந்தை போ", "சேமிப்பு காட்டு", "அரிசி விலை", "என் பதிவு"',
    },
    'kn-IN': {
      welcome:      n  => `ಕೃಷಿ ಶೇಖರಣೆಗೆ ಸ್ವಾಗತ, ${n}! ಹೋಮ್, ಶೇಖರಣೆ, ಮಾರುಕಟ್ಟೆ ಅಥವಾ ಬುಕಿಂಗ್ ಎಂದು ಹೇಳಿ.`,
      page_home:    () => 'ಮುಖಪುಟ ತೆರೆಯುತ್ತಿದ್ದೇವೆ.',
      page_storage: () => 'ಶೇಖರಣಾ ಪಟ್ಟಿ ತೆರೆಯುತ್ತಿದ್ದೇವೆ.',
      page_market:  () => 'ಮಾರುಕಟ್ಟೆ ದರಗಳು ತೋರಿಸುತ್ತಿದ್ದೇವೆ.',
      page_bookings:() => 'ನಿಮ್ಮ ಬುಕಿಂಗ್‌ಗಳು ತೋರಿಸುತ್ತಿದ್ದೇವೆ.',
      help:         () => 'ಹೋಮ್, ಶೇಖರಣೆ, ಮಾರುಕಟ್ಟೆ ಅಥವಾ ಬುಕಿಂಗ್ ಎಂದು ಹೇಳಿ.',
      price_info:   (c,p) => `${c} ಪ್ರಸ್ತುತ ಬೆಲೆ ₹${p} ಕ್ವಿಂಟಾಲ್‌ಗೆ.`,
      theme_dark:   () => 'ಡಾರ್ಕ್ ಮೋಡ್.',
      theme_light:  () => 'ಲೈಟ್ ಮೋಡ್.',
      logout:       () => 'ಲಾಗ್ ಔಟ್ ಆಗುತ್ತಿದ್ದೀರಿ. ಧನ್ಯವಾದ!',
      not_found:    () => 'ಕ್ಷಮಿಸಿ, ಅರ್ಥವಾಗಲಿಲ್ಲ. ಮತ್ತೆ ಹೇಳಿ.',
      listening:    () => 'ಆಲಿಸುತ್ತಿದ್ದೇನೆ...',
      examples:     () => '"ಮಾರುಕಟ್ಟೆಗೆ ಹೋಗು", "ಶೇಖರಣೆ ತೋರಿಸು", "ಅಕ್ಕಿ ಬೆಲೆ", "ನನ್ನ ಬುಕಿಂಗ್"',
    },
    'ml-IN': {
      welcome:      n  => `കൃഷി സ്‌റ്റോറേജിലേക്ക് സ്വാഗതം, ${n}! ഹോം, സ്റ്റോറേജ്, മാർക്കറ്റ്, ബുക്കിംഗ് എന്ന് പറയൂ.`,
      page_home:    () => 'ഹോം പേജ് തുറക്കുന്നു.',
      page_storage: () => 'സ്‌റ്റോറേജ് ഡയറക്‌ടറി തുറക്കുന്നു.',
      page_market:  () => 'മാർക്കറ്റ് വിലകൾ കാണിക്കുന്നു.',
      page_bookings:() => 'നിങ്ങളുടെ ബുക്കിംഗുകൾ കാണിക്കുന്നു.',
      help:         () => 'ഹോം, സ്റ്റോറേജ്, മാർക്കറ്റ്, ബുക്കിംഗ് എന്ന് പറയൂ.',
      price_info:   (c,p) => `${c} നിലവിലെ വില ₹${p} ക്വിന്റലിന്.`,
      theme_dark:   () => 'ഡാർക്ക് മോഡ് ഓൺ.',
      theme_light:  () => 'ലൈറ്റ് മോഡ് ഓൺ.',
      logout:       () => 'ലോഗ് ഔട്ട് ആകുന്നു. നന്ദി!',
      not_found:    () => 'ക്ഷമിക്കണം, മനസ്സിലായില്ല. വീണ്ടും പറയൂ.',
      listening:    () => 'ശ്രദ്ധിക്കുന്നു...',
      examples:     () => '"മാർക്കറ്റ് പോകൂ", "സ്റ്റോറേജ് കാണിക്കൂ", "അരി വില", "എന്റെ ബുക്കിംഗ്"',
    },
    'mr-IN': {
      welcome:      n  => `कृषी साठवणुकीत आपले स्वागत, ${n}! होम, स्टोरेज, मार्केट किंवा बुकिंग सांगा.`,
      page_home:    () => 'होम पेज उघडत आहोत.',
      page_storage: () => 'स्टोरेज यादी उघडत आहोत.',
      page_market:  () => 'बाजार भाव दाखवत आहोत.',
      page_bookings:() => 'आपल्या बुकिंग दाखवत आहोत.',
      help:         () => 'होम, स्टोरेज, मार्केट किंवा बुकिंग म्हणा.',
      price_info:   (c,p) => `${c} चा सध्याचा भाव ₹${p} प्रति क्विंटल.`,
      theme_dark:   () => 'डार्क मोड चालू.',
      theme_light:  () => 'लाइट मोड चालू.',
      logout:       () => 'लॉग आउट होत आहे. धन्यवाद!',
      not_found:    () => 'माफ करा, समजले नाही. पुन्हा सांगा.',
      listening:    () => 'ऐकत आहे...',
      examples:     () => '"बाजारात जा", "स्टोरेज दाखव", "गहू भाव", "माझी बुकिंग"',
    },
    'gu-IN': {
      welcome:      n  => `કૃષિ સ્ટોરેજમાં આપનું સ્વાગત, ${n}! હોમ, સ્ટોરેજ, માર્કેટ અથવા બુકિંગ કહો.`,
      page_home:    () => 'હોમ પેજ ખોલી રહ્યા છીએ.',
      page_storage: () => 'સ્ટોરેજ ડિરેક્ટરી ખોલી રહ્યા છીએ.',
      page_market:  () => 'બજાર ભાવ દેખાડી રહ્યા છીએ.',
      page_bookings:() => 'તમારી બુકિંગ દેખાડી રહ્યા છીએ.',
      help:         () => 'હોમ, સ્ટોરેજ, માર્કેટ અથવા બુકિંગ કહો.',
      price_info:   (c,p) => `${c} નો વર્તમાન ભાવ ₹${p} પ્રતિ ક્વિન્ટલ.`,
      theme_dark:   () => 'ડાર્ક મોડ ચાલુ.',
      theme_light:  () => 'લાઇટ મોડ ચાલુ.',
      logout:       () => 'લૉગ આઉટ થઈ રહ્યા છો. આભાર!',
      not_found:    () => 'માફ કરો, સમજ ન આવ્યું. ફરી કહો.',
      listening:    () => 'સાંભળી રહ્યો છું...',
      examples:     () => '"બજાર જાઓ", "સ્ટોરેજ બતાવો", "ઘઉં ભાવ", "મારી બુકિંગ"',
    },
    'pa-IN': {
      welcome:      n  => `ਕਿਸਾਨ ਸਟੋਰੇਜ ਵਿੱਚ ਜੀ ਆਇਆਂ ਨੂੰ, ${n}! ਹੋਮ, ਸਟੋਰੇਜ, ਮਾਰਕੀਟ ਜਾਂ ਬੁਕਿੰਗ ਕਹੋ।`,
      page_home:    () => 'ਹੋਮ ਪੇਜ ਖੁੱਲ੍ਹ ਰਿਹਾ ਹੈ।',
      page_storage: () => 'ਸਟੋਰੇਜ ਸੂਚੀ ਖੁੱਲ੍ਹ ਰਹੀ ਹੈ।',
      page_market:  () => 'ਬਾਜ਼ਾਰ ਭਾਅ ਦਿਖਾਏ ਜਾ ਰਹੇ ਹਨ।',
      page_bookings:() => 'ਤੁਹਾਡੀਆਂ ਬੁਕਿੰਗਾਂ ਦਿਖਾਈਆਂ ਜਾ ਰਹੀਆਂ ਹਨ।',
      help:         () => 'ਹੋਮ, ਸਟੋਰੇਜ, ਮਾਰਕੀਟ ਜਾਂ ਬੁਕਿੰਗ ਕਹੋ।',
      price_info:   (c,p) => `${c} ਦਾ ਮੌਜੂਦਾ ਭਾਅ ₹${p} ਪ੍ਰਤੀ ਕੁਇੰਟਲ।`,
      theme_dark:   () => 'ਡਾਰਕ ਮੋਡ ਚਾਲੂ।',
      theme_light:  () => 'ਲਾਈਟ ਮੋਡ ਚਾਲੂ।',
      logout:       () => 'ਲੌਗ ਆਊਟ ਹੋ ਰਿਹਾ ਹੈ। ਧੰਨਵਾਦ!',
      not_found:    () => 'ਮਾਫ਼ ਕਰਨਾ, ਸਮਝ ਨਹੀਂ ਆਇਆ। ਦੁਬਾਰਾ ਕਹੋ।',
      listening:    () => 'ਸੁਣ ਰਿਹਾ ਹਾਂ...',
      examples:     () => '"ਮਾਰਕੀਟ ਜਾਓ", "ਸਟੋਰੇਜ ਦਿਖਾਓ", "ਕਣਕ ਭਾਅ", "ਮੇਰੀ ਬੁਕਿੰਗ"',
    },
    'bn-IN': {
      welcome:      n  => `কৃষি স্টোরেজে আপনাকে স্বাগতম, ${n}! হোম, স্টোরেজ, মার্কেট বা বুকিং বলুন।`,
      page_home:    () => 'হোম পেজ খুলছি।',
      page_storage: () => 'স্টোরেজ ডিরেক্টরি খুলছি।',
      page_market:  () => 'বাজার মূল্য দেখাচ্ছি।',
      page_bookings:() => 'আপনার বুকিং দেখাচ্ছি।',
      help:         () => 'হোম, স্টোরেজ, মার্কেট বা বুকিং বলুন।',
      price_info:   (c,p) => `${c} এর বর্তমান মূল্য ₹${p} প্রতি কুইন্টাল।`,
      theme_dark:   () => 'ডার্ক মোড চালু।',
      theme_light:  () => 'লাইট মোড চালু।',
      logout:       () => 'লগ আউট হচ্ছে। ধন্যবাদ!',
      not_found:    () => 'দুঃখিত, বুঝতে পারিনি। আবার বলুন।',
      listening:    () => 'শুনছি...',
      examples:     () => '"মার্কেটে যাও", "স্টোরেজ দেখাও", "ধান দাম", "আমার বুকিং"',
    },
  };

  /* ── Command patterns (multilingual) ──────────────────── */
  const CMDS = {
    home: [
      /\b(home|dashboard|main page|go home|start|beginning)\b/i,
      /\b(होम|घर|मुख्य|शुरुआत)\b/,
      /\b(హోమ్|మొదటి|ప్రారంభ)\b/,
      /\b(முகப்பு|இல்லம்|ஆரம்பம்)\b/,
      /\b(ಮುಖಪುಟ|ಹೋಮ್)\b/,
      /\b(ഹോം|ആരംഭ)\b/,
      /\b(होम पेज|मुख्यपृष्ठ)\b/,
      /\b(ਹੋਮ|ਮੁੱਖ)\b/,
      /\b(হোম|মূল)\b/,
    ],
    storage: [
      /\b(storage|cold storage|warehouse|facility|facilities|find storage|store|godown)\b/i,
      /\b(भंडारण|गोदाम|कोल्ड स्टोरेज|स्टोरेज)\b/,
      /\b(నిల్వ|స్టోరేజ్|గోదాం)\b/,
      /\b(சேமிப்பு|கிடங்கு|குளிர்சாலை)\b/,
      /\b(ಶೇಖರಣೆ|ಸ್ಟೋರೇಜ್)\b/,
      /\b(സ്‌റ്റോറേജ്|ഗോഡൗൺ)\b/,
      /\b(साठवण|स्टोरेज)\b/,
      /\b(ਸਟੋਰੇਜ|ਗੁਦਾਮ)\b/,
      /\b(স্টোরেজ|গুদাম)\b/,
    ],
    market: [
      /\b(market|price|prices|mandi|rates|crop price|commodity|market price)\b/i,
      /\b(बाजार|मार्केट|दाम|कीमत|मंडी|भाव)\b/,
      /\b(మార్కెట్|ధర|ధరలు|మండి)\b/,
      /\b(சந்தை|விலை|மண்டி)\b/,
      /\b(ಮಾರುಕಟ್ಟೆ|ಬೆಲೆ|ಮಂಡಿ)\b/,
      /\b(മാർക്കറ്റ്|വില)\b/,
      /\b(बाजारभाव|मंडई)\b/,
      /\b(ਬਾਜ਼ਾਰ|ਮੰਡੀ|ਭਾਅ)\b/,
      /\b(বাজার|মূল্য|মান্ডি)\b/,
    ],
    bookings: [
      /\b(booking|bookings|my booking|reservation|reserved|my storage)\b/i,
      /\b(बुकिंग|आरक्षण|मेरी बुकिंग)\b/,
      /\b(బుకింగ్|రిజర్వేషన్|నా బుకింగ్)\b/,
      /\b(முன்பதிவு|என் பதிவு)\b/,
      /\b(ಬುಕಿಂಗ್|ಮೀಸಲಾತಿ)\b/,
      /\b(ബുക്കിംഗ്|റിസർവേഷൻ)\b/,
      /\b(बुकिंग|आरक्षण)\b/,
      /\b(ਬੁਕਿੰਗ|ਰਾਖਵਾਂਕਰਨ)\b/,
      /\b(বুকিং|সংরক্ষণ)\b/,
    ],
    help: [
      /\b(help|what can you do|assist|guide|commands|how to use)\b/i,
      /\b(मदद|सहायता|कमांड)\b/,
      /\b(సహాయం|ఏమి చేయగలవు)\b/,
      /\b(உதவி|என்ன செய்யலாம்)\b/,
      /\b(ಸಹಾಯ|ಏನು ಮಾಡಬಹುದು)\b/,
    ],
    dark:  [ /\b(dark|night|dark mode|dark theme)\b/i, /\b(डार्क|रात)\b/, /\b(ডার্ক|রাত)\b/ ],
    light: [ /\b(light|day|light mode|bright)\b/i,    /\b(लाइट|दिन)\b/, /\b(লাইট|দিন)\b/ ],
    logout:[ /\b(logout|log out|sign out|exit|quit|bye)\b/i, /\b(लॉगआउट|बाहर|निकलो)\b/, /\b(లాగ్ అవుట్|నిష్క్రమణ)\b/ ],
    /* Price queries */
    rice:     [ /\b(rice|paddy|dhan|धान|चावल|బియ్యం|நெல்|अरिसि|ভাত|ধান)\b/i ],
    wheat:    [ /\b(wheat|gehu|గోధుమ|கோதுமை|گندم|গম|ਕਣਕ)\b/i ],
    maize:    [ /\b(maize|corn|makka|మొక్కజొన్న|சோளம்|మకказ)\b/i ],
    tomato:   [ /\b(tomato|tamatar|టొమాటో|தக்காளி|ٹماٹر)\b/i ],
    onion:    [ /\b(onion|pyaaz|ఉల్లి|வெங்காயம்|ਪਿਆਜ਼)\b/i ],
    cotton:   [ /\b(cotton|kapas|పత్తి|பருத்தி|ਕਪਾਹ)\b/i ],
    groundnut:[ /\b(groundnut|peanut|moongfali|వేరుశెనగ|கடலை|ਮੂੰਗਫਲੀ)\b/i ],
    mango:    [ /\b(mango|aam|మామిడి|மாம்பழம்|ਅੰਬ)\b/i ],
  };

  /* ── Private state ─────────────────────────────────────── */
  let recog       = null;
  let isListening = false;
  let isPanelOpen = false;
  let lang        = 'en-IN';
  let cachedPrices= [];
  const synth     = window.speechSynthesis;

  /* ── Helper: get lang strings ─────────────────────────── */
  const T = (key, ...args) => {
    const src = LANG_DATA[lang] || LANG_DATA['en-IN'];
    const fn  = src[key] || LANG_DATA['en-IN'][key];
    return fn ? fn(...args) : key;
  };

  /* ── TTS speak ─────────────────────────────────────────────
     Plain speak — used for welcome / ambient announcements.
     Does NOT auto-restart listening.
  ────────────────────────────────────────────────────────── */
  const speak = text => {
    if (!synth) return;
    synth.cancel();
    const utt  = new SpeechSynthesisUtterance(text);
    utt.lang   = lang;
    utt.rate   = 0.95;
    utt.pitch  = 1.05;
    const voices = synth.getVoices();
    const pick = voices.find(v => v.lang === lang)
              || voices.find(v => v.lang.startsWith(lang.split('-')[0]))
              || voices.find(v => v.lang.includes('IN'))
              || null;
    if (pick) utt.voice = pick;
    synth.speak(utt);
  };

  /* ── alexaSpeak — Alexa-style TTS ──────────────────────────
     Speaks the response AND then automatically restarts the
     microphone so the user can chain commands hands-free,
     just like Alexa / Google Assistant.
  ────────────────────────────────────────────────────────── */
  const alexaSpeak = (text, autoRestart = true) => {
    if (!synth) return;
    synth.cancel();
    const utt   = new SpeechSynthesisUtterance(text);
    utt.lang    = lang;
    utt.rate    = 0.95;
    utt.pitch   = 1.05;
    const voices = synth.getVoices();
    const pick  = voices.find(v => v.lang === lang)
               || voices.find(v => v.lang.startsWith(lang.split('-')[0]))
               || voices.find(v => v.lang.includes('IN'))
               || null;
    if (pick) utt.voice = pick;

    /* After the assistant finishes speaking, auto-restart mic */
    utt.onend = () => {
      if (autoRestart && recog && !isListening) {
        // Small pause so the mic doesn't pick up the tail of TTS echo
        setTimeout(() => {
          try {
            recog.lang = lang;
            recog.start();
            setListening(true);
            setStatus('🎤 ' + T('listening'));   // show "Listening…"
          } catch (e) { /* already started or not available */ }
        }, 400);
      }
    };
    synth.speak(utt);
  };

  /* ── Add chat bubble ─────────────────────────────────── */
  const addBubble = (text, role) => {
    const chat = $('vaChat');
    const d    = el('div', 'va-bubble ' + role, text);
    chat.appendChild(d);
    chat.scrollTop = chat.scrollHeight;
  };

  /* ── Match transcript to command ──────────────────────── */
  const matchCmd = text => {
    for (const [cmd, patterns] of Object.entries(CMDS))
      if (patterns.some(p => p.test(text))) return cmd;
    return null;
  };

  /* ── Execute command ──────────────────────────────────────
     Every navigation command speaks an exact "Navigating to…"
     line via alexaSpeak so the mic auto-restarts afterwards.
  ────────────────────────────────────────────────────────── */
  const exec = cmd => {
    const priceMap = {
      rice: 'Rice', wheat: 'Wheat', maize: 'Maize',
      tomato: 'Tomato', onion: 'Onion', cotton: 'Cotton',
      groundnut: 'Groundnut', mango: 'Mango',
    };

    if (priceMap[cmd]) {
      const crop  = priceMap[cmd];
      const found = cachedPrices.find(p => p.crop === crop);
      if (found) {
        const msg = T('price_info', crop, found.currentPrice.toLocaleString());
        addBubble('🤖 ' + msg, 'asst');
        alexaSpeak(msg, true);        // Alexa-style: auto-restarts mic after
        App.navigate('market');
      }
      return;
    }

    /* ── Navigation commands — exact "Navigating to…" speech ── */
    const navPhrases = {
      'en-IN': {
        home:     'Navigating to Home page.',
        storage:  'Navigating to Storage Directory.',
        market:   'Navigating to Market Prices.',
        bookings: 'Navigating to My Bookings.',
      },
      'hi-IN': {
        home:     'होम पेज पर जा रहे हैं।',
        storage:  'भंडारण सूची पर जा रहे हैं।',
        market:   'बाजार भाव पेज पर जा रहे हैं।',
        bookings: 'आपकी बुकिंग पेज पर जा रहे हैं।',
      },
      'te-IN': {
        home:     'హోమ్ పేజీకి నావిగేట్ అవుతున్నాం.',
        storage:  'స్టోరేజ్ డైరెక్టరీకి నావిగేట్ అవుతున్నాం.',
        market:   'మార్కెట్ ధరలకు నావిగేట్ అవుతున్నాం.',
        bookings: 'మీ బుకింగ్‌లకు నావిగేట్ అవుతున్నాం.',
      },
      'ta-IN': {
        home:     'முகப்பு பக்கத்திற்கு செல்கிறோம்.',
        storage:  'சேமிப்பு பட்டியலுக்கு செல்கிறோம்.',
        market:   'சந்தை விலைகளுக்கு செல்கிறோம்.',
        bookings: 'உங்கள் முன்பதிவுகளுக்கு செல்கிறோம்.',
      },
      'kn-IN': {
        home:     'ಮುಖಪುಟಕ್ಕೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುತ್ತಿದ್ದೇವೆ.',
        storage:  'ಶೇಖರಣಾ ಪಟ್ಟಿಗೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುತ್ತಿದ್ದೇವೆ.',
        market:   'ಮಾರುಕಟ್ಟೆ ದರಗಳಿಗೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುತ್ತಿದ್ದೇವೆ.',
        bookings: 'ನಿಮ್ಮ ಬುಕಿಂಗ್‌ಗಳಿಗೆ ನ್ಯಾವಿಗೇಟ್ ಮಾಡುತ್ತಿದ್ದೇವೆ.',
      },
      'ml-IN': {
        home:     'ഹോം പേജിലേക്ക് നാവിഗേറ്റ് ചെയ്യുന്നു.',
        storage:  'സ്‌റ്റോറേജ് ഡയറക്‌ടറിയിലേക്ക് നാവിഗേറ്റ് ചെയ്യുന്നു.',
        market:   'മാർക്കറ്റ് വിലകളിലേക്ക് നാവിഗേറ്റ് ചെയ്യുന്നു.',
        bookings: 'ബുക്കിംഗുകളിലേക്ക് നാവിഗേറ്റ് ചെയ്യുന്നു.',
      },
      'mr-IN': {
        home:     'मुख्यपृष्ठावर जात आहोत.',
        storage:  'स्टोरेज यादीवर जात आहोत.',
        market:   'बाजार भावावर जात आहोत.',
        bookings: 'बुकिंग पानावर जात आहोत.',
      },
      'gu-IN': {
        home:     'હોમ પેજ પર નેવિગેટ કરી રહ્યા છીએ.',
        storage:  'સ્ટોરેજ ડિરેક્ટરી પર નેવિગેટ કરી રહ્યા છીએ.',
        market:   'બજાર ભાવ પર નેવિગેટ કરી રહ્યા છીએ.',
        bookings: 'બુકિંગ પર નેવિગેટ કરી રહ્યા છીએ.',
      },
      'pa-IN': {
        home:     'ਹੋਮ ਪੇਜ ਤੇ ਜਾ ਰਹੇ ਹਾਂ।',
        storage:  'ਸਟੋਰੇਜ ਸੂਚੀ ਤੇ ਜਾ ਰਹੇ ਹਾਂ।',
        market:   'ਬਾਜ਼ਾਰ ਭਾਅ ਤੇ ਜਾ ਰਹੇ ਹਾਂ।',
        bookings: 'ਬੁਕਿੰਗ ਪੇਜ ਤੇ ਜਾ ਰਹੇ ਹਾਂ।',
      },
      'bn-IN': {
        home:     'হোম পেজে নেভিগেট করছি।',
        storage:  'স্টোরেজ ডিরেক্টরিতে নেভিগেট করছি।',
        market:   'বাজার মূল্যে নেভিগেট করছি।',
        bookings: 'বুকিং পেজে নেভিগেট করছি।',
      },
    };

    /* Helper: pick correct language nav phrase, fallback English */
    const navSay = page => {
      const phrases = navPhrases[lang] || navPhrases['en-IN'];
      return phrases[page] || navPhrases['en-IN'][page];
    };

    switch (cmd) {
      case 'home':
        addBubble('🤖 ' + navSay('home'), 'asst');
        alexaSpeak(navSay('home'), true);
        App.navigate('home');
        setTimeout(closePanel, 1200);
        break;
      case 'storage':
        addBubble('🤖 ' + navSay('storage'), 'asst');
        alexaSpeak(navSay('storage'), true);
        App.navigate('storage');
        setTimeout(closePanel, 1200);
        break;
      case 'market':
        addBubble('🤖 ' + navSay('market'), 'asst');
        alexaSpeak(navSay('market'), true);
        App.navigate('market');
        setTimeout(closePanel, 1200);
        break;
      case 'bookings':
        addBubble('🤖 ' + navSay('bookings'), 'asst');
        alexaSpeak(navSay('bookings'), true);
        App.navigate('bookings');
        setTimeout(closePanel, 1200);
        break;
      case 'help': {
        const helpTxt = T('help');
        addBubble('🤖 ' + helpTxt, 'asst');
        alexaSpeak(helpTxt, true);   // after help, restart mic for next command
        break;
      }
      case 'dark':
        document.documentElement.setAttribute('data-theme', 'dark');
        localStorage.setItem('ks_theme', 'dark');
        App.syncThemeBtn();
        addBubble('🤖 ' + T('theme_dark'), 'asst');
        alexaSpeak(T('theme_dark'), true);
        break;
      case 'light':
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('ks_theme', 'light');
        App.syncThemeBtn();
        addBubble('🤖 ' + T('theme_light'), 'asst');
        alexaSpeak(T('theme_light'), true);
        break;
      case 'logout':
        addBubble('🤖 ' + T('logout'), 'asst');
        alexaSpeak(T('logout'), false);  // no auto-restart on logout
        setTimeout(() => $('logoutBtn').click(), 1600);
        break;
    }
  };

  /* ── Process raw transcript ───────────────────────────── */
  const onResult = text => {
    addBubble('👤 ' + text, 'user');
    setStatus('Processing…');
    const cmd = matchCmd(text);
    if (cmd) {
      exec(cmd);
    } else {
      /* Not understood — speak and auto-restart so user can try again */
      const msg = T('not_found');
      addBubble('🤖 ' + msg, 'asst');
      alexaSpeak(msg, true);   // auto-restart mic = true (Alexa behaviour)
    }
    setStatus(T('listening').replace('...','') + ' · Alt+V');
  };

  /* ── STT control ──────────────────────────────────────── */
  const setListening = val => {
    isListening = val;
    const fab  = $('vaFab');
    const mic  = $('vaMic');
    const ico  = $('vaMicIco');
    const wav  = $('vaWaves');
    const nvb  = $('navVoiceBtn');
    fab.dataset.listening = val;
    mic.dataset.listening = val;
    ico.textContent = val ? '⏹' : '🎤';
    wav.classList.toggle('on', val);
    nvb.classList.toggle('active', val);
    $('vaFabIco').textContent = val ? '⏹' : '🎤';
    setStatus(val ? T('listening') : 'Tap mic · Alt+V');
  };

  const setStatus = txt => { if ($('vaStatus')) $('vaStatus').textContent = txt; };

  const startListening = () => {
    if (!recog || isListening) return;
    try {
      recog.lang = lang;
      recog.start();
      setListening(true);
      addBubble('🎤 ' + T('listening'), 'asst');
    } catch(e) { console.warn('STT start error:', e); }
  };

  const stopListening = () => {
    if (!recog || !isListening) return;
    recog.stop();
    setListening(false);
  };

  const toggleListening = () => isListening ? stopListening() : startListening();

  /* ── Panel control ────────────────────────────────────── */
  const openPanel = () => {
    isPanelOpen = true;
    $('vaPanel').classList.add('open');
    $('vaFabIco').textContent = '✕';
  };
  const closePanel = () => {
    isPanelOpen = false;
    stopListening();
    $('vaPanel').classList.remove('open');
    $('vaFabIco').textContent = isListening ? '⏹' : '🎤';
  };
  const togglePanel = () => isPanelOpen ? closePanel() : openPanel();

  /* ── Update examples text ─────────────────────────────── */
  const updateExamples = () => {
    const ex = $('vaExamples');
    if (ex) ex.textContent = T('examples');
  };

  /* ── INIT ─────────────────────────────────────────────── */
  const init = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      console.warn('SpeechRecognition not supported in this browser');
      $('vaWidget').style.display = 'none';
      $('navVoiceBtn').style.display = 'none';
      return;
    }

    recog                = new SR();
    recog.continuous     = false;
    recog.interimResults = false;
    recog.lang           = lang;

    recog.onresult = e => onResult(e.results[0][0].transcript);
    recog.onerror  = e => {
      setListening(false);
      if (e.error !== 'aborted' && e.error !== 'no-speech')
        addBubble('⚠️ Mic error: ' + e.error, 'asst');
    };
    recog.onend = () => setListening(false);

    /* UI events */
    $('vaFab').addEventListener('click', togglePanel);
    $('vaX').addEventListener('click',   closePanel);
    $('vaMic').addEventListener('click', toggleListening);
    $('navVoiceBtn').addEventListener('click', () => { openPanel(); startListening(); });

    $('vaLang').addEventListener('change', e => {
      lang = e.target.value;
      recog.lang = lang;
      updateExamples();
      speak(T('help'));
    });

    /* Keyboard shortcut Alt+V */
    document.addEventListener('keydown', e => {
      if (e.altKey && e.key.toLowerCase() === 'v') {
        e.preventDefault();
        openPanel();
        startListening();
      }
    });

    /* Pre-load voices */
    if (synth) synth.onvoiceschanged = () => synth.getVoices();

    updateExamples();
  };

  /* ── Public API ───────────────────────────────────────── */
  return {
    init,
    exec,           // exposed for quick-cmd buttons in HTML
    speak,          // plain TTS (no mic restart)
    alexaSpeak,     // Alexa-style TTS → auto-restarts mic after
    addBubble,
    cachePrices: arr => { cachedPrices = arr; },
    welcomeVoice: name => {
      /* After login — personal welcome + then Alexa auto-restart */
      const msg = T('welcome', name);
      setTimeout(() => {
        addBubble('🤖 ' + msg, 'asst');
        alexaSpeak(msg, true);  // speak welcome → restart mic so user can speak immediately
      }, 900);
    },
    getLang: () => lang,
  };
})();

/* ───────────────────────────────────────────────────────────────────────
   5. AUTH  (OTP + Phone login)
─────────────────────────────────────────────────────────────────────── */
const Auth = {
  user: null,
  _otpEmail: '',
  _timer: null,
  _secs: 0,

  init() {
    this._bindUI();
    const tok = Api.getToken();
    if (tok) {
      Api.me()
        .then(u => { this.user = u; App.showApp(); })
        .catch(() => { Api.setToken(null); App.showAuth(); });
    } else {
      App.showAuth();
    }
  },

  _bindUI() {
    /* Method toggle */
    $('tabGmail').addEventListener('click', () => this._setMethod('gmail'));
    $('tabPhone').addEventListener('click',  () => this._setMethod('phone'));

    /* OTP flow */
    $('sendOtpBtn').addEventListener('click', () => this.sendOtp());
    $('backBtn').addEventListener('click',    () => this._goStep1());
    $('verifyBtn').addEventListener('click',  () => this.verifyOtp());
    $('resendBtn').addEventListener('click',  () => this.sendOtp(true));

    /* OTP boxes */
    document.querySelectorAll('.ob').forEach((box, i, all) => {
      box.addEventListener('input', e => {
        e.target.value = e.target.value.replace(/\D/, '');
        if (e.target.value && all[i + 1]) all[i + 1].focus();
        this._syncBoxStyles();
      });
      box.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !e.target.value && all[i - 1]) all[i - 1].focus();
        if (e.key === 'Enter') this.verifyOtp();
      });
      box.addEventListener('paste', e => {
        const digits = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
        all.forEach((b, j) => b.value = digits[j] || '');
        this._syncBoxStyles();
        e.preventDefault();
      });
    });

    /* Phone tabs */
    $('loginTab').addEventListener('click',  () => this._setPhoneTab('login'));
    $('signupTab').addEventListener('click', () => this._setPhoneTab('signup'));

    /* Phone forms */
    $('loginForm').addEventListener('submit',  async e => { e.preventDefault(); await this._phoneLogin(); });
    $('signupForm').addEventListener('submit', async e => { e.preventDefault(); await this._phoneSignup(); });
    $('guestBtn').addEventListener('click',  async () => await this._guestLogin());

    /* Eye toggles */
    document.querySelectorAll('.eye').forEach(btn => {
      btn.addEventListener('click', () => {
        const inp = $(btn.dataset.t);
        inp.type  = inp.type === 'password' ? 'text' : 'password';
        btn.textContent = inp.type === 'password' ? '👁' : '🙈';
      });
    });

    /* Logout */
    $('logoutBtn').addEventListener('click', () => {
      Api.setToken(null); this.user = null;
      synth && window.speechSynthesis.cancel();
      App.showAuth();
      toast('Logged out successfully');
    });
  },

  /* ── Gmail OTP ── */
  async sendOtp(resend = false) {
    const email = resend ? this._otpEmail : $('emailInput').value.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return this._showErr('Please enter a valid email address');

    this._otpEmail = email;
    const btn      = $('sendOtpBtn');
    btn.disabled   = true;
    btn.innerHTML  = spinner() + ' Sending…';
    this._clearErr();

    try {
      const res = await Api.sendOtp(email);

      /* Dev mode: show OTP on screen */
      const box = $('devBox');
      if (res.devMode && res.devOtp) {
        box.style.display = 'block';
        box.innerHTML = `⚠️ <b>Dev Mode</b> — configure SMTP in <code>.env</code> for real emails<br><strong>${res.devOtp}</strong>`;
      } else {
        box.style.display = 'none';
      }

      $('otpSubtitle').textContent = `OTP sent to ${email}`;
      this._goStep2();
      this._startTimer();
      document.querySelectorAll('.ob').forEach(b => { b.value = ''; b.classList.remove('filled'); });
      document.querySelector('.ob').focus();
    } catch (e) {
      this._showErr(e.message);
    } finally {
      btn.disabled  = false;
      btn.textContent = 'Send OTP →';
    }
  },

  async verifyOtp() {
    const otp  = [...document.querySelectorAll('.ob')].map(b => b.value).join('');
    if (otp.length < 6) return this._showErr('Please enter all 6 digits');

    const btn  = $('verifyBtn');
    btn.disabled  = true;
    btn.innerHTML = spinner() + ' Verifying…';
    this._clearErr();

    try {
      const d = await Api.verifyOtp(this._otpEmail, otp);
      clearInterval(this._timer);
      Api.setToken(d.token);
      this.user = d.user;
      App.showApp();
    } catch (e) {
      this._showErr(e.message);
      document.querySelectorAll('.ob').forEach(b => {
        b.classList.add('shake');
        setTimeout(() => b.classList.remove('shake'), 500);
      });
    } finally {
      btn.disabled    = false;
      btn.textContent = 'Verify & Login ✓';
    }
  },

  _startTimer() {
    clearInterval(this._timer);
    this._secs = 600;
    const tv  = $('timerDisp');
    const rb  = $('resendBtn');
    rb.disabled = true;
    tv.classList.remove('expired');
    this._timer = setInterval(() => {
      this._secs--;
      const m = Math.floor(this._secs / 60);
      const s = this._secs % 60;
      tv.textContent = `${m}:${String(s).padStart(2, '0')}`;
      if (this._secs <= 0) {
        clearInterval(this._timer);
        tv.textContent = 'Expired';
        tv.classList.add('expired');
        rb.disabled = false;
      }
    }, 1000);
  },

  /* ── Phone login ── */
  async _phoneLogin() {
    const phone = $('lpPhone').value.trim();
    const pass  = $('lpPass').value;
    if (phone.length < 10) return this._showErr('Enter valid 10-digit mobile');
    if (!pass)             return this._showErr('Password is required');
    const btn   = $('loginBtn');
    btn.disabled  = true;
    btn.innerHTML = spinner() + ' Logging in…';
    try {
      const d = await Api.login(phone, pass);
      Api.setToken(d.token); this.user = d.user; App.showApp();
    } catch (e) { this._showErr(e.message); }
    finally { btn.disabled = false; btn.textContent = 'Login →'; }
  },

  async _phoneSignup() {
    const name = $('spName').value.trim();
    const phone= $('spPhone').value.trim();
    const loc  = $('spLoc').value.trim();
    const pass = $('spPass').value;
    if (!name)          return this._showErr('Name is required');
    if (phone.length < 10) return this._showErr('Enter valid 10-digit mobile');
    if (pass.length < 6)   return this._showErr('Password must be at least 6 characters');
    const btn = $('signupBtn');
    btn.disabled  = true;
    btn.innerHTML = spinner() + ' Creating account…';
    try {
      const d = await Api.register(name, phone, loc, pass);
      Api.setToken(d.token); this.user = d.user; App.showApp();
    } catch (e) { this._showErr(e.message); }
    finally { btn.disabled = false; btn.textContent = 'Create Account →'; }
  },

  async _guestLogin() {
    const d = await Api.guest();
    Api.setToken(d.token); this.user = d.user; App.showApp();
  },

  /* ── UI helpers ── */
  _setMethod(m) {
    $('tabGmail').classList.toggle('active', m === 'gmail');
    $('tabPhone').classList.toggle('active', m === 'phone');
    $('gmail-section').classList.toggle('show', m === 'gmail');
    $('phone-section').classList.toggle('show', m === 'phone');
    this._clearErr();
  },
  _setPhoneTab(t) {
    $('loginTab').classList.toggle('active',   t === 'login');
    $('signupTab').classList.toggle('active',  t === 'signup');
    $('loginForm').classList.toggle('show',    t === 'login');
    $('signupForm').classList.toggle('show',   t === 'signup');
    this._clearErr();
  },
  _goStep1() { $('step1').classList.add('show'); $('step2').classList.remove('show'); },
  _goStep2() { $('step2').classList.add('show'); $('step1').classList.remove('show'); },
  _showErr(msg) { const e = $('authErr'); e.textContent = '⚠ ' + msg; e.style.display = 'block'; },
  _clearErr()   { $('authErr').style.display = 'none'; },
  _syncBoxStyles() { document.querySelectorAll('.ob').forEach(b => b.classList.toggle('filled', !!b.value)); },

  updateNav() {
    if (!this.user) return;
    $('nbAvatar').textContent = this.user.name[0].toUpperCase();
    $('nbName').textContent   = this.user.name.split(' ')[0];
    $('heroGreet').textContent = `Namaste, ${this.user.name.split(' ')[0]} 👋`;
  },
};

/* ───────────────────────────────────────────────────────────────────────
   6. HOME PAGE
─────────────────────────────────────────────────────────────────────── */
const HomePage = {
  async load() {
    try {
      const [mkt, facs] = await Promise.all([Api.market(), Api.facilities()]);
      VA.cachePrices(mkt);

      /* Ticker */
      const doubleMkt = [...mkt, ...mkt];
      $('tickerTrack').innerHTML = doubleMkt.map(p =>
        `<span class="ticker-item">${p.icon} <b>${p.crop}</b> ₹${p.currentPrice.toLocaleString()}
         <span class="${p.isUp ? 't-up' : 't-dn'}">${p.isUp ? '▲' : '▼'} ${Math.abs(p.changePercent)}%</span></span>`
      ).join('');

      /* Stats */
      $('scFacilities').textContent = facs.count;
      $('hfFacilities').textContent = facs.count;

      /* Price grid */
      $('homePrices').innerHTML = mkt.slice(0, 6).map(p => `
        <div class="pc" onclick="App.navigate('market')">
          <div class="pc-ico">${p.icon}</div>
          <div class="pc-name">${p.crop}</div>
          <div class="pc-price">₹${p.currentPrice.toLocaleString()}</div>
          <div class="pc-chg ${p.isUp ? 'up' : 'dn'}">${p.isUp ? '▲' : '▼'} ${Math.abs(p.changePercent)}%</div>
        </div>`).join('');

      /* Nearby facilities (top 3) */
      $('homeFacilities').innerHTML = facs.facilities.slice(0, 3).map(f => FacilityCard.render(f)).join('');
      $('homeFacilities').querySelectorAll('.fc-card').forEach((card, i) => {
        card.addEventListener('click', () => FacilityModal.open(facs.facilities[i]));
        const bb = card.querySelector('.book-btn');
        if (bb) bb.addEventListener('click', e => { e.stopPropagation(); BookModal.open(facs.facilities[i]); });
      });
    } catch (err) { console.error('Home load error', err); }
  },
};

/* ───────────────────────────────────────────────────────────────────────
   7. STORAGE PAGE
─────────────────────────────────────────────────────────────────────── */
const StoragePage = {
  _facs: [],
  _grid: false,

  async init() {
    $('applyBtn').addEventListener('click',  () => this.load());
    $('clearBtn').addEventListener('click',  () => {
      ['srSearch', 'srSort', 'srCrop', 'srState'].forEach(id => {
        const el = $(id);
        el.value = el.tagName === 'SELECT'
          ? (id === 'srSort' ? 'distance' : 'All') : '';
      });
      this.load();
    });
    $('srSearch').addEventListener('keydown', e => { if (e.key === 'Enter') this.load(); });
    $('listVb').addEventListener('click', () => this._setView(false));
    $('gridVb').addEventListener('click', () => this._setView(true));
    await this.load();
  },

  _setView(grid) {
    this._grid = grid;
    $('listVb').classList.toggle('active', !grid);
    $('gridVb').classList.toggle('active',  grid);
    $('facilitiesList').classList.toggle('grid-v', grid);
  },

  async load() {
    const q = {};
    const s = $('srSearch').value.trim(); if (s) q.search = s;
    const o = $('srSort').value;          if (o && o !== 'distance') q.sortBy = o; else q.sortBy = 'distance';
    const c = $('srCrop').value;          if (c && c !== 'All') q.crop = c;
    const st= $('srState').value;         if (st && st !== 'All') q.state = st;

    const list = $('facilitiesList');
    list.innerHTML = [0,1,2].map(() => `<div class="skel" style="height:90px;margin-bottom:12px"></div>`).join('');

    try {
      const data = await Api.facilities(q);
      this._facs = data.facilities;
      $('resultsLbl').textContent = `${data.count} facilit${data.count === 1 ? 'y' : 'ies'} found`;

      if (this._grid) list.classList.add('grid-v');

      if (!data.count) {
        list.innerHTML = `<div class="empty"><div class="empty-ico">🏭</div>
          <div class="empty-t">No facilities found</div>
          <div class="empty-s">Try different filters</div></div>`;
        return;
      }

      list.innerHTML = data.facilities.map((f, i) =>
        `<div style="animation-delay:${i * 0.06}s">${FacilityCard.render(f)}</div>`
      ).join('');

      list.querySelectorAll('.fc-card').forEach((card, i) => {
        card.addEventListener('click', () => FacilityModal.open(this._facs[i]));
        const bb = card.querySelector('.book-btn');
        if (bb) bb.addEventListener('click', e => { e.stopPropagation(); BookModal.open(this._facs[i]); });
      });
    } catch (e) {
      list.innerHTML = `<p style="color:var(--red);padding:24px">Failed to load. Is the server running?</p>`;
    }
  },
};

/* Shared facility card renderer */
const FacilityCard = {
  render(f) {
    const occ = parseFloat(f.occupancyPct || 0);
    const fc  = occ > 80 ? 'var(--red)' : occ > 60 ? 'var(--orange)' : 'var(--g600)';
    return `
    <div class="fc-card">
      <div class="fc-thumb" style="background:${f.imageColor}22">${f.emoji || '🏭'}</div>
      <div class="fc-body">
        <div class="fc-top">
          <div class="fc-name">${f.name}</div>
          ${f.isVerified ? '<span class="fc-veri">✔ Verified</span>' : ''}
        </div>
        <div class="fc-loc">📍 ${f.location}, ${f.state} · ${f.distanceKm} km away</div>
        <div class="fc-tags">
          <span class="tag tg">₹${f.pricePerTonPerMonth}/ton/mo</span>
          <span class="tag to">${f.availableTons}T free</span>
          <span class="tag ta">${'★'.repeat(Math.round(f.rating))} ${f.rating} (${f.reviewCount})</span>
          ${f.crops.slice(0, 2).map(c => `<span class="tag tb">${c}</span>`).join('')}
          ${f.crops.length > 2 ? `<span class="tag tb">+${f.crops.length - 2}</span>` : ''}
        </div>
        <div class="avail-lbl">${f.availableTons} / ${f.capacityTons} tons available</div>
        <div class="avail-bar"><div class="avail-fill" style="width:${occ}%;background:${fc}"></div></div>
      </div>
      <div class="fc-action">
        <button class="btn-primary book-btn" style="padding:10px 16px;font-size:13px">Book →</button>
      </div>
    </div>`;
  },
};

/* ───────────────────────────────────────────────────────────────────────
   8. FACILITY MODAL
─────────────────────────────────────────────────────────────────────── */
const FacilityModal = {
  _cur: null,
  async open(f) {
    try { f = await Api.facility(f.id); } catch {}
    this._cur = f;
    const occ = parseFloat(f.occupancyPct || 0);
    const fc  = occ > 80 ? 'var(--red)' : occ > 60 ? 'var(--orange)' : 'var(--g600)';

    $('fcModalBody').innerHTML = `
      <div class="fm-hero" style="background:linear-gradient(135deg,${f.imageColor}44,${f.imageColor}18)">
        <span style="font-size:80px">${f.emoji || '🏭'}</span>
        ${f.isVerified ? '<div class="fm-veri">✔ Government Verified</div>' : ''}
      </div>
      <div class="fm-body">
        <div class="fm-title">${f.name}</div>
        <div class="fm-loc">📍 ${f.address || f.location + ', ' + f.state}</div>
        <div class="fm-qstats">
          <div class="fm-qs"><div class="fm-qs-val">₹${f.pricePerTonPerMonth}</div><div class="fm-qs-lbl">per ton/month</div></div>
          <div class="fm-qs"><div class="fm-qs-val">${f.distanceKm} km</div><div class="fm-qs-lbl">distance</div></div>
          <div class="fm-qs"><div class="fm-qs-val" style="color:var(--g700)">${f.availableTons}T</div><div class="fm-qs-lbl">available</div></div>
        </div>
        ${f.description ? `<p style="font-size:14px;color:var(--txt2);margin-bottom:20px;line-height:1.65">${f.description}</p>` : ''}
        <div class="fm-sect">
          <div class="fm-sect-t">Availability</div>
          <div class="avail-detail">
            <div class="avail-nums">
              <div><div class="an-val">${f.capacityTons}T</div><div class="an-lbl">Total Capacity</div></div>
              <div><div class="an-val" style="color:var(--g700)">${f.availableTons}T</div><div class="an-lbl">Available</div></div>
              <div><div class="an-val" style="color:var(--orange)">${f.capacityTons - f.availableTons}T</div><div class="an-lbl">Occupied</div></div>
            </div>
            <div class="avail-bar-lg"><div class="avail-fill-lg" style="width:${occ}%;background:${fc}"></div></div>
            <div style="font-size:12px;color:var(--txt3);margin-top:6px">${occ}% occupied</div>
          </div>
        </div>
        <div class="fm-sect">
          <div class="fm-sect-t">Accepted Crops</div>
          <div class="fm-crops">${f.crops.map(c => `<span class="ct">${c}</span>`).join('')}</div>
        </div>
        <div class="fm-sect">
          <div class="fm-sect-t">Amenities</div>
          <div class="fm-amen">${f.amenities.map(a => `<div class="am-item"><span style="color:var(--g600)">✓</span>${a}</div>`).join('')}</div>
        </div>
        ${f.reviews?.length ? `
        <div class="fm-sect">
          <div class="fm-sect-t">Reviews</div>
          ${f.reviews.slice(0, 3).map(r => `
            <div class="rv">
              <div class="rv-top"><span class="rv-name">${r.user}</span><span class="rv-date">${r.date} · ${'★'.repeat(r.rating)}</span></div>
              <div class="rv-text">${r.comment}</div>
            </div>`).join('')}
        </div>` : ''}
      </div>
      <div class="fm-actions">
        <button class="btn-primary" style="flex:1" id="fmBookBtn">Book Storage →</button>
        <button class="btn-outline" onclick="FacilityModal.close()">Close</button>
      </div>`;

    $('fmBookBtn').addEventListener('click', () => { this.close(); BookModal.open(f); });
    $('fcModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
  },
  close() { $('fcModal').style.display = 'none'; document.body.style.overflow = ''; },
};

/* ───────────────────────────────────────────────────────────────────────
   9. BOOKING MODAL
─────────────────────────────────────────────────────────────────────── */
const BookModal = {
  _fac: null,
  open(f) {
    if (!Auth.user || Auth.user.role === 'guest') {
      toast('⚠ Please log in to book storage', true); return;
    }
    this._fac = f;
    $('bkFname').textContent = '📍 ' + f.name + ', ' + f.location;
    $('bkCrop').innerHTML    = f.crops.map(c => `<option value="${c}">${c}</option>`).join('');
    const today = new Date().toISOString().slice(0, 10);
    const next  = new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10);
    $('bkStart').value = today; $('bkStart').min = today;
    $('bkEnd').value   = next;  $('bkEnd').min   = today;
    $('bkQty').value   = '';
    $('bkNotes').value = '';
    this._recalc();
    ['bkQty', 'bkStart', 'bkEnd'].forEach(id => $(id).addEventListener('input', () => this._recalc()));
    $('bkModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
  },
  _recalc() {
    const f  = this._fac; if (!f) return;
    const q  = parseFloat($('bkQty').value) || 0;
    const s  = new Date($('bkStart').value);
    const en = new Date($('bkEnd').value);
    const months = Math.max(1, Math.ceil((en - s) / (864e5 * 30)));
    const total  = q * f.pricePerTonPerMonth * months;
    $('costPreview').innerHTML = `
      <div class="cp-row"><span>Rate</span><span>₹${f.pricePerTonPerMonth}/ton/month</span></div>
      <div class="cp-row"><span>Quantity</span><span>${q || '—'} tons</span></div>
      <div class="cp-row"><span>Duration</span><span>${months} month${months > 1 ? 's' : ''}</span></div>
      <hr class="cp-div"/>
      <div class="cp-row"><strong>Total Cost</strong><span class="cp-total">₹${total > 0 ? total.toLocaleString() : '—'}</span></div>`;
  },
  close() { $('bkModal').style.display = 'none'; document.body.style.overflow = ''; },
};

/* ───────────────────────────────────────────────────────────────────────
   10. MARKET PAGE
─────────────────────────────────────────────────────────────────────── */
const MarketPage = {
  _prices: [],
  _sel: null,

  async init() {
    try {
      this._prices = await Api.market();
      VA.cachePrices(this._prices);

      /* Crop chips */
      $('cropChips').innerHTML = this._prices.map((p, i) =>
        `<button class="chip ${i === 0 ? 'active' : ''}" data-crop="${p.crop}">${p.icon} ${p.crop}</button>`
      ).join('');
      $('cropChips').querySelectorAll('.chip').forEach(btn => {
        btn.addEventListener('click', () => {
          $('cropChips').querySelectorAll('.chip').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          this._renderHero(this._prices.find(p => p.crop === btn.dataset.crop));
        });
      });

      /* Table */
      $('mktTbody').innerHTML = this._prices.map(p => `
        <tr>
          <td><strong>${p.icon} ${p.crop}</strong></td>
          <td><strong style="font-family:var(--mono)">₹${p.currentPrice.toLocaleString()}</strong><br>
              <small style="color:var(--txt3)">${p.unit}</small></td>
          <td style="color:${p.isUp ? 'var(--g700)' : 'var(--red)'};font-weight:700;font-family:var(--mono)">
              ${p.isUp ? '+' : ''}${p.changePercent}%</td>
          <td style="font-family:var(--mono)">${p.msp ? '₹' + p.msp.toLocaleString() : '—'}</td>
          <td><span class="rec ${p.recommendation === 'sell' ? 'rec-sell' : 'rec-hold'}">
              ${p.recommendation === 'sell' ? '🟢 SELL' : '🟡 HOLD'}</span></td>
        </tr>`).join('');

      this._renderHero(this._prices[0]);
    } catch (e) { console.error('Market load error', e); }
  },

  _renderHero(p) {
    this._sel = p;
    const h = $('priceHeroCard');
    h.className = 'price-hero-card ' + (p.isUp ? 'up' : 'dn');
    h.innerHTML = `
      <div class="phc-label">Current Market Rate</div>
      <div class="phc-crop">${p.icon} ${p.crop}</div>
      <div class="phc-price">₹${p.currentPrice.toLocaleString()}</div>
      <div class="phc-unit">${p.unit}</div>
      <div class="phc-badge">${p.isUp ? '▲' : '▼'} ${p.isUp ? '+' : ''}${p.changePercent}% from yesterday</div>
      <div class="phc-prev">Previous: ₹${p.previousPrice.toLocaleString()}${p.msp ? ' · MSP: ₹' + p.msp.toLocaleString() : ''}</div>
      <div class="phc-rec">💡 ${p.recommendationText}</div>`;

    /* Chart */
    const prices = p.weeklyPrices;
    const min = Math.min(...prices) * 0.99;
    const max = Math.max(...prices) * 1.01;
    const range = max - min;
    const bars  = $('chartBars');
    bars.innerHTML = prices.map((val, i) => {
      const h = range > 0 ? ((val - min) / range) * 100 : 50;
      const isToday = i === prices.length - 1;
      const color = isToday
        ? (p.isUp ? '#2E7D32' : '#B71C1C')
        : (p.isUp ? '#81C784' : '#EF9A9A');
      return `
        <div class="bar-w">
          <div class="bar-v">₹${val.toLocaleString()}</div>
          <div class="bar-b" style="height:${Math.max(h, 5)}%;background:${color}" data-v="₹${val.toLocaleString()}"></div>
          <div class="bar-d">${p.weeklyDates[i]}</div>
        </div>`;
    }).join('');
  },
};

/* ───────────────────────────────────────────────────────────────────────
   11. BOOKINGS PAGE
─────────────────────────────────────────────────────────────────────── */
const BookingsPage = {
  async load() {
    const wrap = $('bkWrap');
    if (!Auth.user || Auth.user.role === 'guest') {
      wrap.innerHTML = `<div class="empty"><div class="empty-ico">🔒</div>
        <div class="empty-t">Login required</div>
        <div class="empty-s">Sign in to view your bookings</div>
        <button class="btn-primary" onclick="App.showAuth()">Login Now</button></div>`;
      return;
    }

    wrap.innerHTML = '<div class="skel" style="height:130px;margin-bottom:16px"></div>'.repeat(2);

    try {
      const bks = await Api.bookings();
      $('scBookings').textContent = bks.filter(b => b.status === 'active').length;
      $('hfBookings').textContent = bks.length;

      if (!bks.length) {
        wrap.innerHTML = `<div class="empty">
          <div class="empty-ico">📋</div>
          <div class="empty-t">No bookings yet</div>
          <div class="empty-s">Book cold storage to preserve your crops and sell at the right time</div>
          <button class="btn-primary" onclick="App.navigate('storage')">Find Storage →</button></div>`;
        return;
      }

      wrap.innerHTML = bks.map((b, i) => {
        const daysLeft = Math.ceil((new Date(b.endDate) - Date.now()) / 864e5);
        const urgent   = daysLeft <= 7 && b.status === 'active';
        return `
        <div class="bk-card" style="animation-delay:${i * 0.07}s">
          <div class="bk-head" style="background:${b.status === 'active' ? 'rgba(56,142,60,.07)' : b.status === 'pending' ? 'rgba(245,127,23,.07)' : 'rgba(198,40,40,.07)'}">
            <div class="bk-id">Booking #${b.id}</div>
            <span class="sbadge s-${b.status}">${b.status.toUpperCase()}</span>
          </div>
          <div class="bk-body">
            <div class="bk-grid">
              <div class="bk-item"><label>Facility</label><span>${b.facility?.name || 'N/A'}</span></div>
              <div class="bk-item"><label>Location</label><span>${b.facility?.location || '—'}</span></div>
              <div class="bk-item"><label>Crop</label><span>${b.cropName}</span></div>
              <div class="bk-item"><label>Quantity</label><span>${b.quantityTons} Tons</span></div>
              <div class="bk-item"><label>Duration</label><span>${fmt(b.startDate)} → ${fmt(b.endDate)}</span></div>
              <div class="bk-item"><label>Total Cost</label><span class="bk-cost">₹${Number(b.totalCost).toLocaleString()}</span></div>
            </div>
            ${b.status === 'active' ? `<div class="bk-days ${urgent ? 'warn' : 'ok'}">
              ⏱ ${daysLeft > 0 ? daysLeft + ' days remaining' : 'Period has ended'}</div>` : ''}
            <div class="bk-acts">
              ${b.facility?.contactNumber ? `<a href="tel:${b.facility.contactNumber}" class="btn-outline" style="padding:9px 16px;font-size:13px;flex:1">📞 Contact</a>` : ''}
              ${b.status !== 'cancelled' ? `<button class="btn-outline" style="padding:9px 16px;font-size:13px;border-color:var(--red);color:var(--red)" onclick="BookingsPage.cancel('${b.id}')">Cancel</button>` : ''}
            </div>
          </div>
        </div>`;
      }).join('');
    } catch (e) {
      wrap.innerHTML = `<p style="color:var(--red);padding:32px">Failed to load bookings.</p>`;
    }
  },

  async cancel(id) {
    if (!confirm('Cancel this booking? This cannot be undone.')) return;
    try {
      await Api.cancelBooking(id);
      toast('✅ Booking cancelled');
      await this.load();
    } catch (e) { toast(e.message, true); }
  },
};

/* ───────────────────────────────────────────────────────────────────────
   12. APP CONTROLLER
─────────────────────────────────────────────────────────────────────── */
const App = {
  _page: 'auth',
  _inited: new Set(),

  showAuth() {
    $('navbar').classList.add('hidden');
    $('vaWidget').style.display = 'none';
    ['pg-home', 'pg-storage', 'pg-market', 'pg-bookings'].forEach(id => $(id).classList.remove('show'));
    $('pg-auth').classList.add('show');
    this._page = 'auth';
  },

  showApp() {
    $('pg-auth').classList.remove('show');
    $('navbar').classList.remove('hidden');
    $('vaWidget').style.display = '';
    Auth.updateNav();
    VA.welcomeVoice(Auth.user.name.split(' ')[0]);
    this.navigate('home');
  },

  async navigate(page) {
    /* Hide all pages */
    ['pg-home', 'pg-storage', 'pg-market', 'pg-bookings', 'pg-auth']
      .forEach(id => $(id).classList.remove('show'));

    /* Update nav links */
    document.querySelectorAll('.nl').forEach(l => l.classList.toggle('active', l.dataset.p === page));
    this._page = page;

    /* Show target */
    $('pg-' + page).classList.add('show');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    /* Page announcements via TTS on each navigation */
    const pageAnnounce = {
      home:     () => VA.speak('Home page. View market prices and facilities.'),
      storage:  () => VA.speak('Storage Directory. Find cold storage near you.'),
      market:   () => VA.speak('Market Prices. Live mandi rates.'),
      bookings: () => VA.speak('My Bookings. Your storage reservations.'),
    };
    // Only announce on navigation if not first load (welcome already spoken)
    if (this._inited.size > 0 && pageAnnounce[page]) {
      // Small delay to not conflict with any ongoing speech
      setTimeout(() => { if (!window.speechSynthesis?.speaking) pageAnnounce[page]?.(); }, 400);
    }

    /* Init pages once */
    if (!this._inited.has(page)) {
      this._inited.add(page);
      switch (page) {
        case 'home':     await HomePage.load();    break;
        case 'storage':  await StoragePage.init();  break;
        case 'market':   await MarketPage.init();   break;
        case 'bookings': await BookingsPage.load(); break;
      }
    } else {
      /* Re-load data-sensitive pages */
      if (page === 'bookings') await BookingsPage.load();
      if (page === 'home') {
        try {
          const bks = await Api.bookings().catch(() => []);
          $('scBookings').textContent = bks.filter(b => b.status === 'active').length;
          $('hfBookings').textContent = bks.length;
        } catch {}
      }
    }
  },

  syncThemeBtn() {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    $('themeBtn').textContent = dark ? '☀️' : '🌙';
  },

  _bindGlobal() {
    /* Nav brand */
    $('brandHome').addEventListener('click', () => this.navigate('home'));

    /* Nav links */
    document.querySelectorAll('.nl').forEach(l =>
      l.addEventListener('click', () => this.navigate(l.dataset.p))
    );

    /* [data-nav] buttons */
    document.querySelectorAll('[data-nav]').forEach(b =>
      b.addEventListener('click', () => this.navigate(b.dataset.nav))
    );

    /* Hamburger */
    $('burger').addEventListener('click', () => $('nbLinks').classList.toggle('open'));
    document.addEventListener('click', e => {
      if (!$('burger').contains(e.target) && !$('nbLinks').contains(e.target))
        $('nbLinks').classList.remove('open');
    });

    /* Theme */
    const savedTheme = localStorage.getItem('ks_theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    this.syncThemeBtn();
    $('themeBtn').addEventListener('click', () => {
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
      localStorage.setItem('ks_theme', isDark ? 'light' : 'dark');
      this.syncThemeBtn();
    });

    /* Facility modal */
    $('fcModalX').addEventListener('click', () => FacilityModal.close());
    $('fcModal').addEventListener('click', e => { if (e.target === $('fcModal')) FacilityModal.close(); });

    /* Booking modal */
    $('bkModalX').addEventListener('click', () => BookModal.close());
    $('bkModal').addEventListener('click', e => { if (e.target === $('bkModal')) BookModal.close(); });

    /* Booking form submit */
    $('bkForm').addEventListener('submit', async e => {
      e.preventDefault();
      const f   = BookModal._fac; if (!f) return;
      const qty = parseFloat($('bkQty').value);
      const s   = $('bkStart').value;
      const en  = $('bkEnd').value;
      const btn = $('confirmBk');

      if (!qty || qty <= 0)          return toast('Enter valid quantity', true);
      if (qty > f.availableTons)     return toast(`Only ${f.availableTons} tons available`, true);
      if (!s || !en)                  return toast('Please select dates', true);
      if (new Date(en) <= new Date(s)) return toast('End date must be after start date', true);

      btn.disabled  = true;
      btn.innerHTML = spinner() + ' Confirming…';
      try {
        await Api.createBooking({
          facilityId:   f.id,
          cropName:     $('bkCrop').value,
          quantityTons: qty,
          startDate:    s,
          endDate:      en,
          notes:        $('bkNotes').value,
        });
        BookModal.close();
        toast('✅ Booking confirmed!');
        VA.alexaSpeak('Your storage booking has been confirmed! Say Home, Storage, Market or Bookings to continue.', true);
        this._inited.delete('bookings'); // force reload
      } catch (err) {
        toast(err.message, true);
      } finally {
        btn.disabled    = false;
        btn.textContent = 'Confirm Booking ✓';
      }
    });

    /* Close dropdowns on outside click */
    document.addEventListener('click', e => {
      if (!$('nbUser').contains(e.target)) $('nbDropdown').classList.remove('open');
    });
    $('nbUser').addEventListener('click', e => {
      e.stopPropagation();
      $('nbDropdown').classList.toggle('open');
    });
  },
};

/* ───────────────────────────────────────────────────────────────────────
   13. BOOT
─────────────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  /* Load TTS voices early */
  if (window.speechSynthesis) {
    window.speechSynthesis.getVoices();
    window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
  }

  App._bindGlobal();
  VA.init();        // Init voice assistant (STT + TTS)

  /* ── WEBSITE LOAD WELCOME SPEECH ───────────────────────────
     Speaks "Welcome to Agri Storage" as soon as the splash
     screen appears — just like Alexa greeting on startup.
  ─────────────────────────────────────────────────────────── */
  setTimeout(() => {
    VA.speak('Welcome to Agri Storage. India\'s smart platform for cold storage and live market prices.');
  }, 1200);   // 1.2 s — splash letters are animating, voice greets during animation

  Splash.run();     // Splash hides after 4.2s, then calls Auth.init()
});
