/* ═══════════════════════════════════════════════════════════
   KISAN STORAGE  addon.js  v1.0
   New flow:  SPARKS splash → Landing page → New Login → App
   Features:
     • Immersive landing page with farm SVG scene
     • Alexa speaks "Welcome to Kisan Storage" on landing
     • New email+name+OTP login (no phone number)
     • After login: speaks "Welcome back, [Name]!"
     • User profile page with bookings & activity
   ─────────────────────────────────────────────────────────
   IMPORTANT: This file never modifies main.js functions.
   It REPLACES the Splash callback (Auth.init) by wrapping
   the original Splash.run timeout flow via monkey-patching
   only the post-splash destination. All existing pages,
   auth system, API, and voice assistant remain untouched.
══════════════════════════════════════════════════════════════ */

'use strict';

/* ── Shorthand (duplicated locally to be self-contained) ── */
const $a  = id => document.getElementById(id);
const fmtA = d => d ? new Date(d).toLocaleDateString('en-IN', {day:'numeric',month:'short',year:'numeric'}) : '—';

/* ─────────────────────────────────────────────────────────────
   1.  TTS helper  (standalone, uses browser SpeechSynthesis)
───────────────────────────────────────────────────────────── */
const AddonTTS = {
  _voices: [],
  init() {
    if (!window.speechSynthesis) return;
    const load = () => { this._voices = window.speechSynthesis.getVoices(); };
    load();
    window.speechSynthesis.onvoiceschanged = load;
  },
  speak(text, lang = 'en-IN', onEnd = null) {
    if (!window.speechSynthesis) { onEnd?.(); return; }
    window.speechSynthesis.cancel();
    const utt  = new SpeechSynthesisUtterance(text);
    utt.lang   = lang;
    utt.rate   = 0.92;
    utt.pitch  = 1.08;
    const pick = this._voices.find(v => v.lang === lang)
              || this._voices.find(v => v.lang.startsWith('en'))
              || this._voices.find(v => v.lang.includes('IN'))
              || null;
    if (pick) utt.voice = pick;
    if (onEnd) utt.onend = onEnd;
    window.speechSynthesis.speak(utt);
  }
};

/* ─────────────────────────────────────────────────────────────
   2.  LANDING PAGE  controller
───────────────────────────────────────────────────────────── */
const LandingPage = {

  /* Generate random stars into #kslStars */
  _spawnStars() {
    const c = $a('kslStars');
    if (!c) return;
    c.innerHTML = '';
    const count = window.innerWidth < 600 ? 60 : 130;
    for (let i = 0; i < count; i++) {
      const s = document.createElement('div');
      s.className = 'ksl-star';
      const sz = Math.random() * 2.5 + .8;
      s.style.cssText = [
        `width:${sz}px`, `height:${sz}px`,
        `top:${Math.random() * 55}%`,
        `left:${Math.random() * 100}%`,
        `animation-delay:${(Math.random() * 3).toFixed(2)}s`,
        `animation-duration:${(Math.random() * 2 + 2).toFixed(2)}s`,
      ].join(';');
      c.appendChild(s);
    }
  },

  show() {
    this._spawnStars();
    $a('pg-landing').classList.remove('ksl-hidden');

    /* Alexa speaks "Welcome to Kisan Storage" immediately */
    AddonTTS.speak('Welcome to Kisan Storage. India\'s smart platform for cold storage and live mandi prices.');

    /* Enter button → navigate to new login */
    $a('kslEnterBtn').addEventListener('click', () => {
      this.hide();
      NewLogin.show();
    });
  },

  hide() {
    const el = $a('pg-landing');
    el.style.transition = 'opacity .6s ease';
    el.style.opacity = '0';
    setTimeout(() => el.classList.add('ksl-hidden'), 620);
  }
};

/* ─────────────────────────────────────────────────────────────
   3.  NEW LOGIN PAGE  (Name + Email + OTP only, no phone)
───────────────────────────────────────────────────────────── */
const NewLogin = {
  _email: '',
  _name:  '',
  _timer: null,
  _secs:  600,

  show() {
    $a('pg-newlogin').classList.remove('ksl-hidden');
    $a('pg-newlogin').style.opacity = '0';
    requestAnimationFrame(() => {
      $a('pg-newlogin').style.transition = 'opacity .5s ease';
      $a('pg-newlogin').style.opacity    = '1';
    });
    this._bindEvents();
  },

  hide() {
    const el = $a('pg-newlogin');
    el.style.transition = 'opacity .5s ease';
    el.style.opacity = '0';
    setTimeout(() => el.classList.add('ksl-hidden'), 520);
  },

  _bindEvents() {
    /* Prevent duplicate event listeners */
    if (this._bound) return;
    this._bound = true;

    $a('kslSendBtn').addEventListener('click',  () => this.sendOtp());
    $a('kslBackBtn').addEventListener('click',  () => this._goStep1());
    $a('kslVerifyBtn').addEventListener('click',() => this.verifyOtp());
    $a('kslResendBtn').addEventListener('click',() => this.sendOtp(true));

    /* OTP box keyboard navigation */
    const boxes = $a('kslOtpBoxes').querySelectorAll('.ksl-ob');
    boxes.forEach((box, i) => {
      box.addEventListener('input', e => {
        e.target.value = e.target.value.replace(/\D/, '');
        if (e.target.value && boxes[i + 1]) boxes[i + 1].focus();
        this._syncBoxStyles();
      });
      box.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !e.target.value && boxes[i - 1]) boxes[i - 1].focus();
        if (e.key === 'Enter') this.verifyOtp();
      });
      box.addEventListener('paste', e => {
        const digits = (e.clipboardData || window.clipboardData)
          .getData('text').replace(/\D/g, '').slice(0, 6);
        boxes.forEach((b, j) => b.value = digits[j] || '');
        this._syncBoxStyles();
        e.preventDefault();
      });
    });

    /* Enter key on name/email fields */
    [$a('kslName'), $a('kslEmail')].forEach(inp => {
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') this.sendOtp(); });
    });
  },

  async sendOtp(resend = false) {
    const name  = $a('kslName').value.trim();
    const email = resend ? this._email : $a('kslEmail').value.trim();

    if (!resend && !name)
      return this._err(1, 'Please enter your full name');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
      return this._err(1, 'Please enter a valid Gmail address');

    this._name  = name || this._name;
    this._email = email;

    const btn = $a('kslSendBtn');
    btn.disabled = true;
    $a('kslSendTxt').innerHTML = '<span class="spin"></span> Sending…';
    this._clearErr(1);

    try {
      const res = await fetch('/api/otp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send OTP');

      /* Dev mode: show OTP on screen */
      if (data.devMode && data.devOtp) {
        $a('kslDevBox').style.display = 'block';
        $a('kslDevOtp').textContent   = data.devOtp;
      } else {
        $a('kslDevBox').style.display = 'none';
      }

      $a('kslOtpSub').textContent = `OTP sent to ${email}`;
      this._goStep2();
      this._startTimer();
      $a('kslOtpBoxes').querySelectorAll('.ksl-ob').forEach(b => { b.value = ''; b.classList.remove('filled'); });
      $a('kslOtpBoxes').querySelector('.ksl-ob').focus();

    } catch(e) {
      this._err(1, e.message);
    } finally {
      btn.disabled = false;
      $a('kslSendTxt').textContent = 'Send OTP to Gmail →';
    }
  },

  async verifyOtp() {
    const otp = [...$a('kslOtpBoxes').querySelectorAll('.ksl-ob')].map(b => b.value).join('');
    if (otp.length < 6) return this._err(2, 'Please enter all 6 digits');

    const btn = $a('kslVerifyBtn');
    btn.disabled = true;
    $a('kslVerifyTxt').innerHTML = '<span class="spin"></span> Verifying…';
    this._clearErr(2);

    try {
      const res  = await fetch('/api/otp/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: this._email, otp })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Verification failed');

      clearInterval(this._timer);

      /* Store token in localStorage — same key as main.js */
      localStorage.setItem('ks_token', data.token);

      /* Update name if user provided it and it wasn't stored */
      if (this._name && data.user && !data.user.name?.trim()) {
        data.user.name = this._name;
      }

      this.hide();
      AddonFlow.onLoginSuccess(data.user);

    } catch(e) {
      this._err(2, e.message);
      /* Shake all boxes */
      $a('kslOtpBoxes').querySelectorAll('.ksl-ob').forEach(b => {
        b.classList.add('shake');
        setTimeout(() => b.classList.remove('shake'), 500);
      });
    } finally {
      btn.disabled = false;
      $a('kslVerifyTxt').textContent = 'Verify & Login ✓';
    }
  },

  _startTimer() {
    clearInterval(this._timer);
    this._secs = 600;
    const tv  = $a('kslTval');
    const rb  = $a('kslResendBtn');
    rb.disabled = true;
    tv.classList.remove('expired');
    this._timer = setInterval(() => {
      this._secs--;
      const m = Math.floor(this._secs / 60);
      const s = this._secs % 60;
      tv.textContent = `${m}:${String(s).padStart(2, '0')}`;
      if (this._secs <= 0) {
        clearInterval(this._timer);
        tv.textContent = 'Expired';
        tv.classList.add('expired');
        rb.disabled = false;
      }
    }, 1000);
  },

  _goStep1() {
    $a('kslS1').style.display = '';
    $a('kslS2').style.display = 'none';
    this._clearErr(1); this._clearErr(2);
  },
  _goStep2() {
    $a('kslS1').style.display = 'none';
    $a('kslS2').style.display = '';
    this._clearErr(2);
  },
  _err(step, msg) {
    const e = $a('kslErr' + step);
    e.textContent = '⚠ ' + msg;
    e.style.display = 'block';
  },
  _clearErr(step) { $a('kslErr' + step).style.display = 'none'; },
  _syncBoxStyles() {
    $a('kslOtpBoxes').querySelectorAll('.ksl-ob').forEach(b => b.classList.toggle('filled', !!b.value));
  }
};

/* ─────────────────────────────────────────────────────────────
   4.  PROFILE PAGE  controller
───────────────────────────────────────────────────────────── */
const ProfilePage = {

  async load(user) {
    if (!user) return;

    /* Hero */
    $a('kslProfAvatar').textContent = user.name ? user.name[0].toUpperCase() : '?';
    $a('kslProfName').textContent   = user.name  || 'Farmer';
    $a('kslProfEmail').textContent  = user.email || user.phone || '—';
    if (user.role !== 'guest') {
      const v = $a('kslProfVerified');
      if (v) v.style.display = '';
    }

    /* Sidebar details */
    const safe = v => v || '—';
    $a('kslPdName').textContent  = safe(user.name);
    $a('kslPdEmail').textContent = safe(user.email);
    $a('kslPdLoc').textContent   = safe(user.location);
    $a('kslPdSince').textContent = user.createdAt ? fmtA(user.createdAt) : 'Today';
    $a('kslPdRole').textContent  = user.role === 'guest' ? 'Guest User' : 'Farmer / Member';

    /* Fetch bookings */
    let bookings = [];
    try {
      const tok = localStorage.getItem('ks_token');
      const res = await fetch('/api/bookings', { headers: { Authorization: 'Bearer ' + tok } });
      if (res.ok) bookings = await res.json();
    } catch {}

    /* Stats */
    const active  = bookings.filter(b => b.status === 'active').length;
    const spent   = bookings.reduce((s, b) => s + Number(b.totalCost || 0), 0);
    const facSet  = new Set(bookings.map(b => b.facilityId));
    $a('kslPsTotal').textContent  = bookings.length;
    $a('kslPsActive').textContent = active;
    $a('kslPsSpent').textContent  = spent > 0 ? '₹' + spent.toLocaleString('en-IN') : '₹0';
    $a('kslPsFacs').textContent   = facSet.size;

    /* Recent bookings list */
    const bkList = $a('kslProfBkList');
    if (!bookings.length) {
      bkList.innerHTML = `<div class="ksl-empty">
        <div class="ksl-empty-ico">📦</div>
        <div>No bookings yet</div>
        <button class="btn-primary" style="margin-top:14px;padding:10px 22px" onclick="App.navigate('storage')">Find Storage →</button>
      </div>`;
    } else {
      bkList.innerHTML = bookings.slice(0, 5).map(b => `
        <div class="ksl-bk-item" onclick="App.navigate('bookings')">
          <div class="ksl-bk-ico">🏭</div>
          <div class="ksl-bk-info">
            <div class="ksl-bk-name">${b.facility?.name || 'Storage Facility'}</div>
            <div class="ksl-bk-meta">${b.cropName} · ${b.quantityTons}T · ${fmtA(b.startDate)} → ${fmtA(b.endDate)}</div>
          </div>
          <div class="ksl-bk-right">
            <div class="ksl-bk-cost">₹${Number(b.totalCost || 0).toLocaleString('en-IN')}</div>
            <div class="ksl-bk-status s-${b.status}">${b.status.toUpperCase()}</div>
          </div>
        </div>`).join('');
    }

    /* Activity timeline */
    const now   = Date.now();
    const acts  = [
      { ico: '🔑', type: 'login', title: 'Logged in',            desc: 'Accessed Kisan Storage platform',                   when: 'Just now' },
      ...bookings.slice(0, 4).map(b => ({
        ico: '📦', type: 'bk',
        title: `Booking at ${b.facility?.name || 'Storage'}`,
        desc: `${b.cropName} · ${b.quantityTons} tons · ₹${Number(b.totalCost||0).toLocaleString('en-IN')}`,
        when: fmtA(b.startDate),
      })),
      { ico: '📊', type: 'mk', title: 'Checked market prices',   desc: 'Viewed live mandi rates',                           when: fmtA(new Date(now - 864e5)) },
    ];

    $a('kslProfActivity').innerHTML = acts.slice(0, 6).map(a => `
      <div class="ksl-tl-item">
        <div class="ksl-tl-dot ${a.type}">${a.ico}</div>
        <div style="flex:1">
          <div class="ksl-tl-title">${a.title}</div>
          <div class="ksl-tl-desc">${a.desc}</div>
        </div>
        <div class="ksl-tl-time">${a.when}</div>
      </div>`).join('');

    /* Logout button inside profile */
    const lb = $a('kslProfLogout');
    if (lb && !lb._bound) {
      lb._bound = true;
      lb.addEventListener('click', () => $a('logoutBtn').click());
    }
  }
};

/* ─────────────────────────────────────────────────────────────
   5.  ADDON FLOW  — orchestrates the whole new sequence
───────────────────────────────────────────────────────────── */
const AddonFlow = {

  /* Called after successful login via NewLogin */
  onLoginSuccess(user) {
    /* 1. Hand user + token to the existing main.js Auth system */
    Auth.user = user;
    /* api token already saved to localStorage in NewLogin.verifyOtp */

    /* 2. Show the existing app (navbar + home page) */
    App.showApp();  // this calls Auth.updateNav() + VA.welcomeVoice() internally

    /* 3. Override the VA welcome voice to say "Welcome to Kisan Storage, [Name]!"
         We cancel whatever VA.welcomeVoice queued and speak our own version
         after a tiny delay so App.showApp()'s internal call fires first.       */
    setTimeout(() => {
      const firstName = (user.name || 'Farmer').split(' ')[0];
      AddonTTS.speak(
        `Welcome to Kisan Storage, ${firstName}! ` +
        `You can say Home, Storage, Market, or Bookings to navigate.`
      );
    }, 600);
  },

  /* Patch navigate to also handle 'profile' page */
  _patchNavigate() {
    const _orig = App.navigate.bind(App);
    App.navigate = async function(page) {
      if (page === 'profile') {
        /* Hide all pages */
        ['pg-home','pg-storage','pg-market','pg-bookings','pg-auth','pg-profile']
          .forEach(id => { const el = $a(id); if (el) el.classList.remove('show'); });
        document.querySelectorAll('.nl').forEach(l => l.classList.toggle('active', l.dataset.p === 'profile'));
        $a('pg-profile').classList.add('show');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        await ProfilePage.load(Auth.user);
        return;
      }
      return _orig(page);
    };
  },

  /* Intercept Splash.run so our landing page appears instead of Auth page */
  _interceptSplash() {
    const _origRun = Splash.run.bind(Splash);
    Splash.run = function() {
      /* Run the original Splash animation timers */
      /* But replace the final callback (Auth.init) with our landing page */

      /* Replicate the two splash timeouts from original Splash.run */
      setTimeout(() => {
        const splash = $a('splash');
        if (!splash) return;
        splash.style.transition = 'opacity 0.8s ease, visibility 0.8s ease';
        splash.style.opacity    = '0';
        splash.style.visibility = 'hidden';
      }, 3600);

      setTimeout(() => {
        const splash = $a('splash');
        if (splash) splash.remove();

        /* Instead of calling Auth.init() directly, show landing page */
        LandingPage.show();
      }, 4200);
    };
  },

  init() {
    AddonTTS.init();
    this._interceptSplash();
    this._patchNavigate();

    /* If user is already logged in (token in storage), skip landing+login */
    const tok = localStorage.getItem('ks_token');
    if (tok) {
      /* Let original main.js Auth.init handle it (auto-login path) */
      /* But we still need to patch navigate for profile */
    }
  }
};

/* ─────────────────────────────────────────────────────────────
   6.  BOOT  — runs after main.js DOMContentLoaded has fired
───────────────────────────────────────────────────────────── */
window.addEventListener('load', () => {
  AddonFlow.init();
});
