require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

app.use('/api/auth',       require('./routes/auth'));
app.use('/api/otp',        require('./routes/otp'));
app.use('/api/facilities', require('./routes/facilities'));
app.use('/api/market',     require('./routes/market'));
app.use('/api/bookings',   require('./routes/bookings'));

app.get('/api/health', (_, res) => res.json({ ok: true, ts: Date.now() }));
app.get('*', (_, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));

app.listen(PORT, () => {
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║   🌾  KISAN STORAGE PRO  v3.0            ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  App  →  http://localhost:${PORT}            ║`);
  console.log(`║  SMTP →  ${(process.env.GMAIL_USER || 'NOT CONFIGURED').padEnd(30)}║`);
  console.log('╚══════════════════════════════════════════╝\n');
});
