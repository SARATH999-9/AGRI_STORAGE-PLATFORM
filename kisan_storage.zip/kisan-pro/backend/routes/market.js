// market.js
const express=require('express'),router=express.Router(),db=require('../models/db');
const enrich=p=>({...p,changePercent:+(((p.currentPrice-p.previousPrice)/p.previousPrice)*100).toFixed(2),isUp:p.currentPrice>=p.previousPrice});
router.get('/',(_, res)=>res.json(db.marketPrices.map(enrich)));
router.get('/:crop',(req,res)=>{const p=db.marketPrices.find(m=>m.crop.toLowerCase()===req.params.crop.toLowerCase());if(!p)return res.status(404).json({error:'Not found'});res.json(enrich(p));});
module.exports=router;
