const express    = require('express');
const nodemailer = require('nodemailer');
const jwt        = require('jsonwebtoken');
const router     = express.Router();
const db         = require('../models/db');

const SECRET     = process.env.JWT_SECRET   || 'kisan_pro_secret';
const OTP_MS     = (parseInt(process.env.OTP_EXPIRY_MINUTES)||10) * 60000;
const GMAIL_USER = process.env.GMAIL_USER;
const GMAIL_PASS = process.env.GMAIL_APP_PASSWORD;

const genOTP = () => String(Math.floor(100000 + Math.random() * 900000));

const emailHTML = (otp, name, expMins) => `<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f7f0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
<div style="max-width:540px;margin:32px auto;background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 8px 40px rgba(27,94,32,0.15)">
  <div style="background:linear-gradient(135deg,#1B5E20 0%,#388E3C 60%,#66BB6A 100%);padding:40px 40px 32px;text-align:center;position:relative">
    <div style="font-size:52px;margin-bottom:10px">🌾</div>
    <h1 style="color:#fff;margin:0;font-size:28px;font-weight:800;letter-spacing:-0.5px">Kisan Storage</h1>
    <p style="color:rgba(255,255,255,0.82);margin:6px 0 0;font-size:14px;font-style:italic">Store Smart. Sell Right.</p>
  </div>
  <div style="padding:36px 40px">
    <p style="font-size:17px;color:#1A2E1A;margin:0 0 6px;font-weight:600">Namaste, ${name || 'Farmer'} 🙏</p>
    <p style="color:#4A6741;font-size:14px;line-height:1.6;margin:0 0 28px">Your One-Time Password for Kisan Storage login. Valid for <strong>${expMins} minutes</strong>.</p>
    <div style="background:linear-gradient(135deg,#E8F5E9,#F1F8F1);border:2px dashed #4CAF50;border-radius:16px;padding:30px;text-align:center;margin-bottom:28px">
      <div style="font-size:12px;color:#388E3C;font-weight:700;letter-spacing:3px;text-transform:uppercase;margin-bottom:12px">Your OTP</div>
      <div style="font-size:52px;font-weight:900;color:#1B5E20;letter-spacing:14px;font-family:'Courier New',monospace;line-height:1">${otp}</div>
      <div style="font-size:12px;color:#7A9B76;margin-top:12px">Expires in ${expMins} minutes</div>
    </div>
    <div style="background:#FFF8E1;border-left:4px solid #FFA000;border-radius:0 8px 8px 0;padding:12px 16px;margin-bottom:24px">
      <p style="margin:0;font-size:13px;color:#E65100;font-weight:600">⚠️ Security Notice</p>
      <p style="margin:4px 0 0;font-size:12px;color:#795548">Never share this OTP. Kisan Storage will never ask for it via call or chat.</p>
    </div>
    <p style="color:#9E9E9E;font-size:12px;text-align:center;margin:0">If you didn't request this, please ignore this email.</p>
  </div>
  <div style="background:#F4F9F4;padding:20px 40px;text-align:center;border-top:1px solid #E0F0E0">
    <p style="color:#A5C8A5;font-size:12px;margin:0">© 2025 Kisan Storage Platform · Helping India's farmers earn more</p>
  </div>
</div></body></html>`;

// POST /api/otp/send
router.post('/send', async (req, res) => {
  const { email } = req.body;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: 'Valid email required' });

  const otp    = genOTP();
  const expiry = Date.now() + OTP_MS;
  db.otpStore[email] = { otp, expiry };

  const expMins = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10;
  const user    = db.users.find(u => u.email === email);

  // DEV MODE: no SMTP configured
  if (!GMAIL_USER || !GMAIL_PASS || GMAIL_USER.includes('youremail')) {
    console.log(`\n📧 [DEV MODE] OTP for ${email}: ${otp}\n`);
    return res.json({ success:true, devMode:true, devOtp:otp,
      message:`DEV: OTP is ${otp} (configure GMAIL in .env for real emails)` });
  }

  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: { user: GMAIL_USER, pass: GMAIL_PASS },
    });
    await transporter.sendMail({
      from:    `"Kisan Storage 🌾" <${GMAIL_USER}>`,
      to:      email,
      subject: `${otp} — Your Kisan Storage OTP (valid ${expMins} min)`,
      html:    emailHTML(otp, user?.name, expMins),
    });
    res.json({ success:true, message:`OTP sent to ${email}` });
  } catch(err) {
    console.error('SMTP Error:', err.message);
    res.status(500).json({ error:'Failed to send email. Check GMAIL_APP_PASSWORD in .env', detail:err.message });
  }
});

// POST /api/otp/verify
router.post('/verify', (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error:'Email and OTP required' });

  const rec = db.otpStore[email];
  if (!rec)              return res.status(400).json({ error:'No OTP sent. Please request one.' });
  if (Date.now() > rec.expiry) { delete db.otpStore[email]; return res.status(400).json({ error:'OTP expired. Request a new one.' }); }
  if (rec.otp !== String(otp).trim()) return res.status(400).json({ error:'Incorrect OTP. Try again.' });

  delete db.otpStore[email];

  // Auto-create user if first login
  let user = db.users.find(u => u.email === email);
  if (!user) {
    const namePart = email.split('@')[0].replace(/[._\-0-9]/g,' ').trim()
      .split(' ').map(w => w ? w[0].toUpperCase()+w.slice(1) : '').join(' ').trim() || 'Farmer';
    user = { id:'U'+Date.now(), name:namePart, email, phone:'', password:'',
      location:'India', role:'farmer', createdAt:new Date() };
    db.users.push(user);
  }

  const token = jwt.sign({ id:user.id, email:user.email }, SECRET, { expiresIn:'30d' });
  const { password:_, ...safe } = user;
  res.json({ success:true, token, user:safe });
});

module.exports = router;
