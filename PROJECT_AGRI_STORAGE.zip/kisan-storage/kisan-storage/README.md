# Kisan Storage — Full-stack (Node/Express + vanilla JS)
## Run
    cd backend
    npm install
    npm start        # http://localhost:3000   (npm run dev = auto-reload)
Open http://localhost:3000 → Sign up (real email) → Login → OTP arrives via Gmail SMTP.
## Email OTP
Edit backend/.env: SMTP_USER, SMTP_PASS (Gmail App Password; 2-Step Verification must be on).
DEMO_OTP=true makes 123456 always work; set false for real use.
## API
POST /api/register-farmer, /send-otp, /verify-otp, /book-storage
GET /api/storages(/:id), /market-prices, /price-history, /bookings/:phone
## Notes
Users/bookings are stored in backend/data/*.json (swap for MongoDB/Postgres later). Never commit .env.
